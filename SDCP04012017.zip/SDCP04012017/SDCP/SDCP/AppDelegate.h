//
//  AppDelegate.h
//  SDCP
//
//  Created by sravanthi Gumma on 06/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Home.h"
#import <UserNotifications/UserNotifications.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate,UNUserNotificationCenterDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UIViewController *viewController;

@end

