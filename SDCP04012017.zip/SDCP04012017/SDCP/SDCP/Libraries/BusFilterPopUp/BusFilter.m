//
//  BusFilter.m
//  SDCP
//
//  Created by sravanthi Gumma on 14/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import "BusFilter.h"
#import "FilterBus_Cell.h"
#import "ParentView.h"
#import "AdminView.h"
@interface BusFilter ()
{
    NSMutableArray *busCheck;
    NSMutableArray *StudNameArray;
    NSMutableArray *attendeArray;
}
@end

@implementation BusFilter

- (void)viewDidLoad {
    busCheck= [[NSMutableArray alloc]init];
    StudNameArray = [NSMutableArray arrayWithObjects:@"Bus 1",@"Bus 2",@"Bus 3",@"All Buses", nil];
    attendeArray = [[NSMutableArray alloc]init];
    self.view.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.6];
    self.popUpView.layer.cornerRadius = 5;
    self.popUpView.layer.shadowOpacity = 0.8;
    self.popUpView.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
    
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
}
- (void)showAnimate
{
    self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
    self.view.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.view.alpha = 1;
        self.view.transform = CGAffineTransformMakeScale(1, 1);
    }];
    
}

-(IBAction)DoneBtn:(id)sender
{
    
    //busCheck
     [self removeAnimate];
    if ([busCheck containsObject:@"All Buses"]) {
        AdminView *madminView = [[AdminView alloc]initWithNibName:@"AdminView" bundle:nil];
        [self presentViewController:madminView animated:YES completion:nil];
    }
    else
    {
        ParentView *mParentView = [[ParentView alloc]initWithNibName:@"ParentView" bundle:nil];
        [self presentViewController:mParentView animated:YES completion:nil];
        
    }
    
    
   
}

-(IBAction)closepopupBtn:(id)sender
{
    [self removeAnimate];
}

- (void)removeAnimate
{
    [UIView animateWithDuration:.25 animations:^{
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
        self.view.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (finished) {
            [self.view removeFromSuperview];
        }
    }];
    
    
}

- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated
{
    [aView addSubview:self.view];
    //  self.logoImg.image = image;
    //self.messageLabel.text = message;
    if (animated) {
        [self showAnimate];
    }
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [StudNameArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
    // return 150;
}
// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FilterBus_Cell *cell = (FilterBus_Cell *)[tableView dequeueReusableCellWithIdentifier:@"FilterBus_Cell"];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"FilterBus_Cell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.busname.text = [StudNameArray objectAtIndex:indexPath.row];
   
    
    if ([busCheck containsObject:[StudNameArray objectAtIndex:indexPath.row]]) {
        cell.busCheck.image=[UIImage imageNamed:@"check.png"] ;//
    }
    else{
       cell.busCheck.image=[UIImage imageNamed:@"uncheck.png"] ;//
    }
    
    
  
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSIndexPath *someIndexPath = [tableView indexPathForSelectedRow];
    NSString *studentname =  [StudNameArray objectAtIndex:indexPath.row];
    if([attendeArray containsObject:indexPath]){
        [attendeArray removeObject:indexPath];
        [busCheck removeObject:studentname];
        
    } else {
        [attendeArray addObject:someIndexPath];
        [busCheck addObject:studentname];
    }
    
    [tableView reloadData];
    
    
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
