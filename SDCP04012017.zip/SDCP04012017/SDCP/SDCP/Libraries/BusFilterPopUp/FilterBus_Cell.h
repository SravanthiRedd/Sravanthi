//
//  FilterBus_Cell.h
//  SDCP
//
//  Created by sravanthi Gumma on 14/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilterBus_Cell : UITableViewCell

@property(nonatomic,weak) IBOutlet UILabel *busname;
@property(nonatomic,weak) IBOutlet UIImageView *busCheck;

@end
