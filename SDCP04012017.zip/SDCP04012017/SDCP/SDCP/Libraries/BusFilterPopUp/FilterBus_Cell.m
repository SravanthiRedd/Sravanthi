//
//  FilterBus_Cell.m
//  SDCP
//
//  Created by sravanthi Gumma on 14/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import "FilterBus_Cell.h"

@implementation FilterBus_Cell

@synthesize busname,busCheck;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
