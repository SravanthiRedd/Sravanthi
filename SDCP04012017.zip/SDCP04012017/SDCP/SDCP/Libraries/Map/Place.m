//
//  Place.m
//
//  Created by sravanthi Gumma on 07/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Place.h"


@implementation Place

@synthesize name;
@synthesize description;
@synthesize latitude;
@synthesize longitude;


@end
