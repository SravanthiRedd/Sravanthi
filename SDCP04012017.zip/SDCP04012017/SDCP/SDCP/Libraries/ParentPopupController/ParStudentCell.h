//
//  ParStudentCell.h
//  SDCP
//
//  Created by venkat dubasi on 29/12/16.
//  Copyright © 2016 DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParStudentCell : UITableViewCell
@property(nonatomic,weak) IBOutlet UIImageView *studentImg;
@property(nonatomic,weak) IBOutlet UILabel *studentname;
@property(nonatomic,weak) IBOutlet UILabel *studentRoolNo;
@property(nonatomic,weak) IBOutlet UIButton *AttdenceBtn;
@end
