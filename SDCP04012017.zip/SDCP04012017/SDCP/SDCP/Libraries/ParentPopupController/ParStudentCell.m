//
//  ParStudentCell.m
//  SDCP
//
//  Created by venkat dubasi on 29/12/16.
//  Copyright © 2016 DEVPOINT. All rights reserved.
//

#import "ParStudentCell.h"

@implementation ParStudentCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
