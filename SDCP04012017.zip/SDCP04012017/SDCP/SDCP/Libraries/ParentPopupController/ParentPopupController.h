//
//  ParentPopupController.h
//  SDCP
//
//  Created by venkat dubasi on 29/12/16.
//  Copyright © 2016 DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParentPopupController : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *popUpView;
@property (weak, nonatomic) IBOutlet UITextField *searchtext;
@property (weak,nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak,nonatomic) IBOutlet UIView *SeachView;
@property (weak,nonatomic) IBOutlet UITableView *studentListTable;


- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated;

@end
