//
//  ParentPopupController.m
//  SDCP
//
//  Created by venkat dubasi on 29/12/16.
//  Copyright © 2016 DEVPOINT. All rights reserved.
//

#import "ParentPopupController.h"
#import "ParStudentCell.h"

@interface ParentPopupController ()
{
   NSUserDefaults *mPref;
    NSArray *StudNameArray;
    NSArray *StdRollNoArray;
    NSMutableArray *searchNameResults;
    NSMutableArray *searchRollNoResults;
    NSMutableArray *attendeArray;
    NSMutableArray *attendes;
}

@end

@implementation ParentPopupController

- (void)viewDidLoad {
    
    mPref = [NSUserDefaults standardUserDefaults];
    attendeArray= [[NSMutableArray alloc]init];
    attendes = [[NSMutableArray alloc]init];
    
    self.SeachView.layer.borderWidth=0.5;
    self.SeachView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    
    //self.mobileNumber.text =COUNTRYCODE;
    
    self.view.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.6];
    self.popUpView.layer.cornerRadius = 5;
    self.popUpView.layer.shadowOpacity = 0.8;
    self.popUpView.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
    //self.popUpView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    StudNameArray =[NSArray arrayWithObjects:@"Braeden Nelson",@"Shane Warner", nil];
    StdRollNoArray = [NSArray arrayWithObjects:@"SCL2415", @"SCL2462",nil];
    searchNameResults = [(NSArray*)StudNameArray mutableCopy];
}

- (void)showAnimate
{
    self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
    self.view.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.view.alpha = 1;
        self.view.transform = CGAffineTransformMakeScale(1, 1);
    }];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [StudNameArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
    // return 150;
}
// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ParStudentCell *cell = (ParStudentCell *)[tableView dequeueReusableCellWithIdentifier:@"ParStudentCell"];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ParStudentCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.studentname.text = [StudNameArray objectAtIndex:indexPath.row];
    cell.studentRoolNo.text = [StdRollNoArray objectAtIndex:indexPath.row];
    
    if ([attendes containsObject:[StudNameArray objectAtIndex:indexPath.row]]) {
        [cell.AttdenceBtn setImage:[UIImage imageNamed:@"absent.png"] forState:UIControlStateNormal];//
    }
    else{
        [cell.AttdenceBtn setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    }
    
    
    
    cell.AttdenceBtn.userInteractionEnabled= NO;
    
//    if ([cell.AttdenceBtn.currentImage isEqual:[UIImage imageNamed:@"checkbox.png"]])
//        [cell.AttdenceBtn setImage:[UIImage imageNamed:@"Checked.png"] forState:UIControlStateNormal]; //do some thing here for your image1
    
    return cell;
}

-(void)AttdenceBtn:(UIButton*)sender
{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.studentListTable];
    
    NSIndexPath *indexPath = [self.studentListTable indexPathForRowAtPoint:buttonPosition];
    
    ParStudentCell *cell = [self.studentListTable cellForRowAtIndexPath:indexPath];
    
    
    if (cell.AttdenceBtn.currentBackgroundImage == [UIImage imageNamed:@"check.png"] ) {
        [cell.AttdenceBtn setImage:[UIImage imageNamed:@"absent.png"] forState:UIControlStateNormal];
    }
    else  if (cell.AttdenceBtn.currentBackgroundImage == [UIImage imageNamed:@"absent.png"] )
    {
         [cell.AttdenceBtn setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        
      //   [cell.AttdenceBtn setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    }
    
    
    
   
}

-(IBAction)callBtn:(id)sender

{
    NSString *phoneNumber = [@"tel://" stringByAppendingString:@"415 555 2671"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
}





- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    if (![searchText isEqualToString:@""]) {
        [searchNameResults removeAllObjects];
        NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"SELF contains[c] %@", searchText];
        searchNameResults = [NSMutableArray arrayWithArray: [StudNameArray filteredArrayUsingPredicate:resultPredicate]];
    }
    else
    {
        searchNameResults =[(NSArray*)StudNameArray mutableCopy];;
    }
    [self.studentListTable reloadData];
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSIndexPath *someIndexPath = [tableView indexPathForSelectedRow];
    NSString *studentname =  [StudNameArray objectAtIndex:indexPath.row];
    if([attendeArray containsObject:indexPath]){
        [attendeArray removeObject:indexPath];
        [attendes removeObject:studentname];
        
    } else {
        [attendeArray addObject:someIndexPath];
        [attendes addObject:studentname];
    }
    
    [tableView reloadData];
    
   
}


-(IBAction)DoneBtn:(id)sender
{
    [self removeAnimate];
}

-(IBAction)closepopupBtn:(id)sender
{
    [self removeAnimate];
}

- (void)removeAnimate
{
    [UIView animateWithDuration:.25 animations:^{
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
        self.view.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (finished) {
            [self.view removeFromSuperview];
        }
    }];
    
    //    Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
    //    [self presentViewController:mHome animated:YES completion:nil];
}

- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated
{
    [aView addSubview:self.view];
    //  self.logoImg.image = image;
    //self.messageLabel.text = message;
    if (animated) {
        [self showAnimate];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
