//
//  PopUpViewController.h
//  NMPopUpView
//
//  Created by Nikos Maounis on 9/12/13.
//  Copyright (c) 2013 Nikos Maounis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"

@interface PopUpViewController : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic)  NSString *startAt;
@property (strong, nonatomic)  NSString *Page;
@property (weak, nonatomic) IBOutlet UIView *popUpView;

@property (weak, nonatomic) IBOutlet UITextField *searchtext;
@property (weak,nonatomic) IBOutlet UIButton *cancelBtn;
@property (weak,nonatomic) IBOutlet UIView *SeachView;
@property (weak,nonatomic) IBOutlet UITableView *studentListTable;
@property (weak,nonatomic) IBOutlet NSString *popupTitle;
@property (weak,nonatomic) IBOutlet UILabel *popupTitle1;
@property (weak,nonatomic)  NSString *trip;
@property (weak,nonatomic)  NSString *EndTripString;;
@property (weak,nonatomic)  NSString *studentCovereCnt;;;


- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated;

@end
