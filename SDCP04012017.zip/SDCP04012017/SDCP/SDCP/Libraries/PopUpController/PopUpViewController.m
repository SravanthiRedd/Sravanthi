//
//  PopUpViewController.m
//  NMPopUpView
//
//  Created by Nikos Maounis on 9/12/13.
//  Copyright (c) 2013 Nikos Maounis. All rights reserved.
//

#import "PopUpViewController.h"
#import "StudentCell.h"
#import "Driver2.h"
#import "ParentView.h"

@interface PopUpViewController ()
{
    UITextField *OtptextField;
    NSString *oneTimePassword;
    NSUserDefaults *mPref;
  
   // UITextField *textField;
     UIActivityIndicatorView *spinner;
    NSArray *StdNameArray;
    NSArray *StdRollNoArray;
    NSMutableArray *searchNameResults;
    NSMutableArray *searchRollNoResults;
    
    NSMutableArray *StudenSelectedList;
    NSMutableArray *StudenSelectedindex;
    
    
}
@end

@implementation PopUpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
   
    mPref = [NSUserDefaults standardUserDefaults];

    StudenSelectedList = [[NSMutableArray alloc]init]; ;
     StudenSelectedindex = [[NSMutableArray alloc]init];;
    
    
     self.SeachView.layer.borderWidth=0.5;
     self.SeachView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;

    //self.mobileNumber.text =COUNTRYCODE;
    
    self.view.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.6];
    self.popUpView.layer.cornerRadius = 5;
    self.popupTitle1.text = self.popupTitle;
    self.popUpView.layer.shadowOpacity = 0.8;
    self.popUpView.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
    //self.popUpView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
    
    
    StdNameArray =[NSArray arrayWithObjects:@"Braeden Nelson",@"Shane Warner",@"Mitchel Marsh",@"Mark Wallece",@"Emma Watson", nil];
    StdRollNoArray = [NSArray arrayWithObjects:@"SCL2415", @"SCL2462",@"SCL2407",@"SCL2397",@"SCL2494", nil];
    searchNameResults = [(NSArray*)StdNameArray mutableCopy];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
  
    
    //
  
}

- (void)showAnimate
{
    self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
    self.view.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.view.alpha = 1;
        self.view.transform = CGAffineTransformMakeScale(1, 1);
    }];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [searchNameResults count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65;
    // return 150;
}
// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    StudentCell *cell = (StudentCell *)[tableView dequeueReusableCellWithIdentifier:@"StudentCell"];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.studentname.text = [searchNameResults objectAtIndex:indexPath.row];
    cell.studentRoolNo.text = [StdRollNoArray objectAtIndex:indexPath.row];
    
    if ([StudenSelectedList containsObject:[searchNameResults objectAtIndex:indexPath.row]]) {
        [cell.AttdenceBtn setImage:[UIImage imageNamed:@"uncheck.png"] forState:UIControlStateNormal];//
    }
    else{
        [cell.AttdenceBtn setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    }
    
    cell.AttdenceBtn.userInteractionEnabled= NO;
  
//   [cell.AttdenceBtn addTarget:self action:@selector(AttdenceBtn:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSIndexPath *someIndexPath = [tableView indexPathForSelectedRow];
    NSString *studentname =  [searchNameResults objectAtIndex:indexPath.row];
    if([StudenSelectedindex containsObject:indexPath]){
        [StudenSelectedindex removeObject:indexPath];
        [StudenSelectedList removeObject:studentname];
        
    } else {
        [StudenSelectedindex addObject:someIndexPath];
        [StudenSelectedList addObject:studentname];
    }
    
    [tableView reloadData];
    
}


-(void)AttdenceBtn:(UIButton*)sender
{
  UIImage *avalbleImage = [UIImage imageNamed:@"uncheck.png"];
    
   
}

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    if (![searchText isEqualToString:@""]) {
        [searchNameResults removeAllObjects];
        NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"SELF contains[c] %@", searchText];
        searchNameResults = [NSMutableArray arrayWithArray: [StdNameArray filteredArrayUsingPredicate:resultPredicate]];
    }
    else
    {
        searchNameResults =[(NSArray*)StdNameArray mutableCopy];;
    }
    [self.studentListTable reloadData];
}



-(IBAction)askMealterBtn:(id)sender
{
    [self removeAnimate];
}

-(IBAction)closepopupBtn:(id)sender
{
    [self removeAnimate];
}

- (void)removeAnimate
{
    [UIView animateWithDuration:.25 animations:^{
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
        self.view.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (finished) {
            [self.view removeFromSuperview];
        }
    }];
    
//    Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
//    [self presentViewController:mHome animated:YES completion:nil];
}

- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated
{
    [aView addSubview:self.view];
  //  self.logoImg.image = image;
    //self.messageLabel.text = message;
    if (animated) {
        [self showAnimate];
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    @try {
        if(textField == _searchtext)
        {
            
              if (![_searchtext.text isEqualToString:@""]) {
                
                NSString *substring = [NSString stringWithString:_searchtext.text];
                substring = [substring
                             stringByReplacingCharactersInRange:range withString:string];
                [self searchAutocompleteEntriesWithSubstring:substring];
               
                
                return YES;
            }
        }
              return YES;
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    
    if (![substring isEqualToString:@""]) {
        [searchNameResults removeAllObjects];
        NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"SELF contains[c] %@", substring];
        searchNameResults = [NSMutableArray arrayWithArray: [StdNameArray filteredArrayUsingPredicate:resultPredicate]];
    }
    else
    {
        searchNameResults =[(NSArray*)StdNameArray mutableCopy];;
    }
    [self.studentListTable reloadData];

    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)DoneBtn:(id)sender
{
    [self removeAnimate];
    
    if ([self.Page isEqualToString:@"Parent"]) {
        ParentView *mPrarentView=[[ ParentView alloc]initWithNibName:@"ParentView" bundle:nil];
        
        mPrarentView.restartAt = self.startAt;
        [self presentViewController:mPrarentView animated:YES
                         completion:nil];

    }
    else if ([self.Page isEqualToString:@"Driver"])
    {
        
        Driver2 *mPrarentView=[[ Driver2 alloc]initWithNibName:@"Driver2" bundle:nil];
        
        mPrarentView.restartAt = self.startAt;
        mPrarentView.Trip = _trip;
        mPrarentView.studenCovedCnt = self.studentCovereCnt;
        mPrarentView.endtripString= self.EndTripString;
        [self presentViewController:mPrarentView animated:YES
                         completion:nil];

    }
    
    
    
}

@end
