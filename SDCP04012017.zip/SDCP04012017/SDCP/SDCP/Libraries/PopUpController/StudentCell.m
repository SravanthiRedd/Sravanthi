//
//  StudentCell.m
//  SDCP
//
//  Created by sravanthi Gumma on 07/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import "StudentCell.h"

@implementation StudentCell
@synthesize studentImg= studentImg;
@synthesize studentname= studentname;
@synthesize studentRoolNo= studentRoolNo;
@synthesize AttdenceBtn= AttdenceBtn;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
