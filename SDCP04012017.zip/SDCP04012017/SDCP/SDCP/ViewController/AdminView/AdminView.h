//
//  AdminView.h
//  SDCP
//
//  Created by venkat dubasi on 01/01/17.
//  Copyright © 2017 DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface AdminView : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    CLLocation *currentLocation;  
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
}
@property(strong,nonatomic) NSString *restartAt;
@property(weak,nonatomic) IBOutlet UIButton *FilterBtn;

@end
