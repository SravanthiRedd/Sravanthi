//
//  AdminView.m
//  SDCP
//
//  Created by venkat dubasi on 01/01/17.
//  Copyright © 2017 DEVPOINT. All rights reserved.
//

#import "AdminView.h"
#import "ParentPopupController.h"
#import "MapPoint.h"
#import "PopUpViewController.h"
#import "Home.h"
#import "BusFilter.h"

@interface AdminView ()<UITableViewDelegate,UITableViewDataSource>
{
    
    UITableView *table;
    NSUserDefaults *mPref;
    NSMutableArray *locationObjest;
    NSString *LATITUDE;// =@"Latitude";
    NSString *LONGITUDE;// =@"Longitude";
    NSMutableArray *Busrayya;
    NSTimeInterval timeIntervalForBus1;
    NSTimeInterval timeIntervalForBus2;
    NSTimeInterval timeIntervalForBus3;
    NSTimeInterval timeIntervalForBus4;
    
    NSMutableArray *Bus2Array;
    NSMutableArray *location2Objest;
    
    
    
    NSMutableArray *BusarrayPlaces;
    NSMutableArray *studentPointLocationArray;
    NSMutableArray *bus1track;
    NSMutableArray *bus2track;
    NSMutableArray *bus3track;
    NSMutableArray *bus4track;
    
    UITableView *FilterBus;
    NSTimer *Bus1;
    NSTimer *Bus2;
    NSTimer *Bus3;
    NSTimer *Bus4;
    int Busnumber;
    
    
}
@property (nonatomic, strong)  ParentPopupController *ParentPopupController;
@property (nonatomic, strong)  PopUpViewController *popUpViewController;
@property (nonatomic, strong)  BusFilter *BuspopUpViewController;
@property (nonatomic, strong) IBOutlet MKMapView *mkMapview;

@end

@implementation AdminView
@synthesize mkMapview;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    LATITUDE =@"Latitude";
    LONGITUDE =@"Longitude";
    Busrayya = [[NSMutableArray alloc]init];
//    FilterBus = [[UITableView alloc]initWithFrame:CGRectMake(self.FilterBtn.frame.origin.x-50, self.FilterBtn.frame.origin.y+20, 100, 200) style:UITableViewStylePlain];
//    FilterBus.delegate= self;
//    FilterBus.dataSource = self;
//    FilterBus.hidden= YES;
//    [self.view addSubview:FilterBus];
    
    
    locationObjest = [[NSMutableArray alloc]init];
    
    Bus2Array = [[NSMutableArray alloc]init];
    location2Objest = [[NSMutableArray alloc]init];
    BusarrayPlaces = [NSMutableArray arrayWithObjects:
                       @"28.759710, -81.322058",
                       @"28.759024, -81.320534",
                        @"28.758093, -81.320518",
                        @"28.758107, -81.322757", nil];
    
    NSString *schollHub= @"28.759013, -81.323789";
    [self PlaceschoolHub:schollHub];
    
    
    studentPointLocationArray =[NSMutableArray arrayWithObjects:
                                @"28.759551, -81.322060",
                                @"28.759343, -81.322063",
                               // @"28.759189, -81.322066",
                                //@"28.759056, -81.322070",
                                @"28.759033, -81.320877",
                               // @"28.759038, -81.321371",
                               // @"28.759029, -81.321683",
                                @"28.759027, -81.321971",
                                @"28.758116, -81.322618",
                                @"28.758116, -81.322618",
                                @"28.758370, -81.322099",
                                @"28.758642, -81.322296",
                               // @"28.758931, -81.322334",
                                //@"28.758102, -81.320762",
                                @"28.758105, -81.321269",
                               // @"28.758112, -81.321739",
                                //@"28.758626, -81.322073",
                                nil];
    
    
//    ,
//    @"28.758154, -81.320507",@"28.758088, -81.320832",@"28.758083, -81.321256",@"28.758097, -81.321755",@"28.758172, -81.322061",@"28.758534, -81.322066",@"28.758957, -81.322109",@"28.758113, -81.322642",@"28.758118, -81.322293"
    
    bus1track= [NSMutableArray arrayWithObjects:
                @"28.759710, -81.322058",
                @"28.759665, -81.322058",
                @"28.759624, -81.322062",
                @"28.759589, -81.322058",
                @"28.759551, -81.322060",
                @"28.759589, -81.322058"
                @"28.759439, -81.322059",
                @"28.759387, -81.322055",
                @"28.759343, -81.322063",
                @"28.759299, -81.322059",
                @"28.759258, -81.322062",
                @"28.759216, -81.322063",
                @"28.759189, -81.322066",
                @"28.759139, -81.322068",
                @"28.759091, -81.322070",
                @"28.759056, -81.322070",  
                @"28.759021, -81.322077",
                @"28.759017, -81.322187",
                @"28.759016, -81.322258",
                @"28.759023, -81.322317",
                @"28.759021, -81.322365",
                @"28.759022, -81.322438",
                @"28.759022, -81.322438",
                @"28.759023, -81.322576",
                @"28.759022, -81.322703",
                @"28.759023, -81.322755",
                @"28.759021, -81.322841",
                @"28.759023, -81.322908",
                @"28.759023, -81.323013",
                @"28.759023, -81.323118",
                @"28.759023, -81.323201",
                @"28.759023, -81.323292",
                @"28.759030, -81.323372",
                @"28.759023, -81.323466",
                @"28.759023, -81.323533",
                @"28.759016, -81.323632",
                @"28.759016, -81.323712",
                @"28.759007, -81.323731",nil];
    
    bus2track= [NSMutableArray arrayWithObjects:@"28.759024, -81.320534",
                @"28.759025, -81.320538",
                @"28.759027, -81.320618",
                @"28.759029, -81.320688",
                @"28.759029, -81.320738",
                @"28.759034, -81.320806",
                @"28.759033, -81.320877",
                @"28.759031, -81.320966",
                @"28.759038, -81.321081",
                @"28.759036, -81.321175",
                @"28.759036, -81.321280",
                @"28.759038, -81.321371",
                @"28.759027, -81.321442",
                @"28.759033, -81.321522",
                @"28.759030, -81.321610"
                @"28.759029, -81.321683",
                @"28.759031, -81.321782",
                @"28.759031, -81.321847",
                @"28.759028, -81.321921",
                @"28.759027, -81.321971",
                @"28.759012, -81.322069",
                @"28.759017, -81.322187",
                @"28.759016, -81.322258",
                @"28.759023, -81.322317",
                @"28.759021, -81.322365",
                @"28.759022, -81.322438",
                @"28.759022, -81.322438",
                @"28.759023, -81.322576",
                @"28.759022, -81.322703",
                @"28.759023, -81.322755",
                @"28.759021, -81.322841",
                @"28.759023, -81.322908",
                @"28.759023, -81.323013",
                @"28.759023, -81.323118",
                @"28.759023, -81.323201",
                @"28.759023, -81.323292",
                @"28.759030, -81.323372",
                @"28.759023, -81.323466",
                @"28.759023, -81.323533",
                @"28.759016, -81.323632",
                @"28.759016, -81.323712",
                @"28.759007, -81.323731",nil];
    //28.759033, -81.320877
    //28.759038, -81.321371
    //28.759029, -81.321683
    //28.759027, -81.321971
    
    bus3track= [NSMutableArray arrayWithObjects:
                @"28.758093, -81.320518",
                @"28.758089, -81.320572",
                @"28.758091, -81.320644",
                @"28.758093, -81.320700",
                @"28.758102, -81.320762",
                @"28.758103, -81.320829",
                @"28.758105, -81.320899",
                @"28.758105, -81.320979",
                @"28.758103, -81.321052",
                @"28.758103, -81.321167",
                @"28.758105, -81.321269",
                @"28.758107, -81.321360",
                @"28.758105, -81.321449",
                @"28.758112, -81.321551",
                @"28.758105, -81.321650",
                @"28.758112, -81.321739",
                @"28.758112, -81.321844",
                @"28.758105, -81.321949",
                @"28.758117, -81.322062",
                @"28.758332, -81.322065",
                @"28.758492, -81.322068",
                @"28.758626, -81.322073",
                @"28.758743, -81.322080",
                @"28.758868, -81.322083",
                @"28.758952, -81.322082",
                @"28.759019, -81.322079",
                @"28.759017, -81.322187",
                @"28.759016, -81.322258",
                @"28.759023, -81.322317",
                @"28.759021, -81.322365",
                @"28.759022, -81.322438",
                @"28.759022, -81.322438",
                @"28.759023, -81.322576",
                @"28.759022, -81.322703",
                @"28.759023, -81.322755",
                @"28.759021, -81.322841",
                @"28.759023, -81.322908",
                @"28.759023, -81.323013",
                @"28.759023, -81.323118",
                @"28.759023, -81.323201",
                @"28.759023, -81.323292",
                @"28.759030, -81.323372",
                @"28.759023, -81.323466",
                @"28.759023, -81.323533",
                @"28.759016, -81.323632",
                @"28.759016, -81.323712",
                @"28.759007, -81.323731",nil];
    
    
    bus4track= [NSMutableArray arrayWithObjects:
                @"28.758107, -81.322757",
                @"28.758109, -81.322690",
                @"28.758116, -81.322618",@"@"
                @"28.758116, -81.322516",
                @"28.758100, -81.322393",
                @"28.758102, -81.322313",
                @"28.758104, -81.322230",
                @"28.758104, -81.322154",
                @"28.758105, -81.322085",
                @"28.758180, -81.322088",
                @"28.758244, -81.322096",
                @"28.758370, -81.322099",
                @"28.758444, -81.322098",
                @"28.758489, -81.322125",
                @"28.758496, -81.322174",
                @"28.758514, -81.322261",
                @"28.758572, -81.322286",
                @"28.758642, -81.322296",
                @"28.758694, -81.322301",
                @"28.758756, -81.322311",
                @"28.758806, -81.322313",
                @"28.758866, -81.322326",
                @"28.758931, -81.322334",
                @"28.759000, -81.322347",
                @"28.759022, -81.322438",
                @"28.759023, -81.322576",
                @"28.759022, -81.322703",
                @"28.759023, -81.322755",
                @"28.759021, -81.322841",
                @"28.759023, -81.322908",
                @"28.759023, -81.323013",
                @"28.759023, -81.323118",
                @"28.759023, -81.323201",
                @"28.759023, -81.323292",
                @"28.759030, -81.323372",
                @"28.759023, -81.323466",
                @"28.759023, -81.323533",
                @"28.759016, -81.323632",
                @"28.759016, -81.323712",
                @"28.759007, -81.323731",nil];
    
    [self PlaceBusPositions:BusarrayPlaces];
    [self PlaceStudentLocationPoint:studentPointLocationArray];
    
    // Do any additional setup after loading the view from its nib.
    self.mkMapview.delegate = self;
    
    // Ensure that we can view our own location in the map view.
    //
    
    //Instantiate a location object.
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        //locationManager.allowsBackgroundLocationUpdates = YES;
    }
    [locationManager startUpdatingLocation];
    
    CLLocation *location = [locationManager location];
    // coordinate = [location coordinate];
    CLLocationCoordinate2D centre = [self.mkMapview centerCoordinate];
    //@"28.758107, -81.322757",
    float lat = [@"28.758107" floatValue];
    float longi = [@"-81.322757" floatValue];
    
    centre.latitude = lat;//28.721145//-81.305078
    centre.longitude=longi;
    MKCoordinateRegion region;
    if (firstLaunch) {
        region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1500,1500);
        firstLaunch=YES;
    }else {
        
        
        //  MKCoordinateRegion region;
        region.center.latitude = lat;//{desired lat};
        region.center.longitude =longi;// {desired lng};
        region.span.latitudeDelta = 0.003;
        region.span.longitudeDelta = 0.003;
        region = [mkMapview regionThatFits:region];
        [mkMapview setRegion:region animated:TRUE];
        
    }
    
    //Set the visible region of the map.
    [self.mkMapview setShowsUserLocation:YES];
    // [mkMapview setRegion:region animated:YES];
    // mkMapview.centerCoordinate = location.coordinate;
    timeIntervalForBus1 = 0;
    timeIntervalForBus2 = 0;
    timeIntervalForBus3 = 0;
    timeIntervalForBus4 = 0;
    
     Bus1 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                  target: self
                                                selector:@selector(onTickForBus1:)
                                                userInfo: nil repeats:YES];
    
     Bus2 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                  target: self
                                                selector:@selector(onTickForBus2:)
                                                userInfo: nil repeats:YES];
    
     Bus3 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                     target: self
                                                   selector:@selector(onTickForBus3:)
                                                   userInfo: nil repeats:YES];
    
     Bus4 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                     target: self
                                                   selector:@selector(onTickForBus4:)
                                                   userInfo: nil repeats:YES];

}

//@"28.758823, -81.323599" Bus1
//@"28.758824, -81.323629" Bus2
//@"28.758824, -81.323650" Bus3
//@"28.758823, -81.323677" Bus4


-(void)PlaceschoolHub:(NSString*)place
{
    if (place!=nil) {
        
        CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
        CGSize size = CGSizeMake(28, 36);
        
        NSArray *latlong = [place componentsSeparatedByString:@","];
        
        
        float lat = [[latlong objectAtIndex:0] floatValue];
        float longi = [[latlong objectAtIndex:1] floatValue];
        
        center.latitude = lat;//28.721145//-81.305078
        center.longitude=longi;
        
        for (id<MKAnnotation> annotation in mkMapview.annotations){
            MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
            anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            
            
            UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            [infoButton addTarget:self action:@selector(showDetailsView)
                 forControlEvents:UIControlEventTouchUpInside];
            anView.rightCalloutAccessoryView = infoButton;
            anView.canShowCallout = YES;
            
            //if (anView){
            //  [mapView removeAnnotation:annotation];
            //}
        }
        
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
        
        MKCoordinateSpan span = MKCoordinateSpanMake(0.5, 0.5);
        MKCoordinateRegion region = {coord, span};
        
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        [annotation setCoordinate:coord];
        annotation.title=@"School";
        
        [mkMapview setRegion:region];
        [mkMapview addAnnotation:annotation];
        
    }
    


}



-(void)onTickForBus1:(NSTimer*)Bus1Timer
{
    //plotvehickePosition
    
    if (timeIntervalForBus1 ==[bus1track count] ) {
        [Bus1Timer invalidate];
    }
    else
    {
        
        NSString *busPosition= [bus1track objectAtIndex:timeIntervalForBus1];
        
        [self plotvehickePositionBus1:busPosition];
        timeIntervalForBus1 = timeIntervalForBus1+1;
    }
    
}

-(void)onTickForBus2:(NSTimer*)Bus2Timer
{
    if (timeIntervalForBus2 ==[bus2track count] ) {
        [Bus2Timer invalidate];
    }
    else
    {
        
        NSString *busPosition= [bus2track objectAtIndex:timeIntervalForBus2];
        
        [self plotvehickePositionBus2:busPosition];
        timeIntervalForBus2 = timeIntervalForBus2+1;
    }

}

-(void)onTickForBus3:(NSTimer*)Bus3Timer
{
    if (timeIntervalForBus3 ==[bus3track count] ) {
        [Bus3Timer invalidate];
    }
    else
    {
        
        NSString *busPosition= [bus3track objectAtIndex:timeIntervalForBus3];
        [self plotvehickePositionBus3:busPosition];
        timeIntervalForBus3 = timeIntervalForBus3+1;
    }
    
}

-(void)onTickForBus4:(NSTimer*)Bus4Timer
{
    if (timeIntervalForBus4 ==[bus4track count] ) {
        [Bus4Timer invalidate];
    }
    else
    {
        NSString *busPosition= [bus4track objectAtIndex:timeIntervalForBus4];
        [self plotvehickePositionBus4:busPosition];
        timeIntervalForBus4 = timeIntervalForBus4+1;
    }
    
}

-(void)PlaceBusPositions:(NSMutableArray*)buspositionsArray
{
    @try {
        
        //Remove any existing custom annotations but not the user location blue dot.
        for (id<MKAnnotation> annotation in mkMapview.annotations)
        {
            if ([annotation isKindOfClass:[MapPoint class]])
            {
                [mkMapview removeAnnotation:annotation];
            }
        }
        
        //Loop through the array of places returned from the Google API.
        for (int i=0; i<[buspositionsArray count]; i++)
        {
            
            //Retrieve the NSDictionary object in each index of the array.
            NSString  * place = [buspositionsArray objectAtIndex:i];
            NSArray *latlong = [place componentsSeparatedByString:@","];
            
            //Get our name and address info for adding to a pin.
            int numr = i+1;
            NSString *name=@"Bus";
            NSString *vicinity= @"";
            CLLocationCoordinate2D coordinate;
            
            //Set the lat and long.
            coordinate.latitude=[[latlong objectAtIndex:0] doubleValue];
            coordinate.longitude=[[latlong objectAtIndex:1] doubleValue];
            
            MapPoint *placeObject = [[MapPoint alloc] initWithName:name address:vicinity coordinate:coordinate];
            [mkMapview addAnnotation:placeObject];
            
        }
        
    }
    @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }

}

-(void)PlaceStudentLocationPoint:(NSMutableArray *)studentPointLocationArray
{
    @try {
        
        //Remove any existing custom annotations but not the user location blue dot.
//        for (id<MKAnnotation> annotation in mkMapview.annotations)
//        {
//            if ([annotation isKindOfClass:[MapPoint class]])
//            {
//                [mkMapview removeAnnotation:annotation];
//            }
//        }
        
        //Loop through the array of places returned from the Google API.
        for (int i=0; i<[studentPointLocationArray count]; i++)
        {
            
            //Retrieve the NSDictionary object in each index of the array.
            NSString  * place = [studentPointLocationArray objectAtIndex:i];
            NSArray *latlong = [place componentsSeparatedByString:@","];
            
            //Get our name and address info for adding to a pin.
            int numr = i+1;
            NSString *name=[NSString stringWithFormat:@"%d",numr];
            NSString *vicinity= @"";
            CLLocationCoordinate2D coordinate;
            
            //Set the lat and long.
            coordinate.latitude=[[latlong objectAtIndex:0] doubleValue];
            coordinate.longitude=[[latlong objectAtIndex:1] doubleValue];
            
            MapPoint *placeObject = [[MapPoint alloc] initWithName:name address:vicinity coordinate:coordinate];
            [mkMapview addAnnotation:placeObject];
            
        }
        
    }
    @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }

}


//
-(void)showCurrentLocationAddressss:(NSDictionary*)locatioString
{
    @try {
        
        if (locatioString!=nil) {
            
            CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
            CGSize size = CGSizeMake(28, 36);
            float lat = [[locatioString valueForKey:@"Latitiude"] floatValue];
            float longi = [[locatioString valueForKey:@"Longitude"] floatValue];
            
            center.latitude = lat;//28.721145//-81.305078
            center.longitude=longi;
            
            for (id<MKAnnotation> annotation in mkMapview.annotations){
                MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                
                
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
                
                //if (anView){
                //  [mapView removeAnnotation:annotation];
                //}
            }
            
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
            
            MKCoordinateSpan span = MKCoordinateSpanMake(0.5, 0.5);
            MKCoordinateRegion region = {coord, span};
            
            MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
            [annotation setCoordinate:coord];
            annotation.title=@"Bus";
            
            [mkMapview setRegion:region];
            [mkMapview addAnnotation:annotation];
            
        }
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}

-(void)showDetailsView
{
    self.ParentPopupController = [[ParentPopupController alloc] initWithNibName:@"ParentPopupController" bundle:nil];
    [self.ParentPopupController setTitle:@"This is a popup view"];
    
    [self.ParentPopupController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
}

- (UIImage *)image:(UIImage*)originlimage scaledToSize:(CGSize)size {
    //avoid redundant drawing
    if (CGSizeEqualToSize(originlimage.size, size))
    {
        return originlimage;
    }
    
    //create drawing context
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    
    //draw
    [originlimage drawInRect:CGRectMake(0.0f, 0.0f, size.width, size.height)];
    
    //capture resultant image
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    //return image
    return image;
}

//
- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
    
    if ([[annotation title] isEqualToString:@"Current Location"]) {
        return nil;
    }
    
    CGSize size = CGSizeMake(28, 36);
    
    MKAnnotationView *annView = [[MKAnnotationView alloc ] initWithAnnotation:annotation reuseIdentifier:@"currentloc"];
    if ([[annotation title] isEqualToString:@"Bus"])
    {
        annView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        
        [infoButton addTarget:self action:@selector(showDetailsView)
             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    else if ([[annotation title] isEqualToString:@"BusPostions1"])
    {

        annView.image  = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
       
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        
        [infoButton addTarget:self action:@selector(showDetailsView)
             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    else if([[annotation title] isEqualToString:@"BusPostions2"])
    {
        
        annView.image  = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
     
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        
        [infoButton addTarget:self action:@selector(showDetailsView)
             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;

    }
    else if([[annotation title] isEqualToString:@"BusPostions3"])
    {
        
        annView.image  = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        
        [infoButton addTarget:self action:@selector(showDetailsView)
             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    else if([[annotation title] isEqualToString:@"BusPostions4"])
    {
        
        annView.image  = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
       
        [infoButton addTarget:self action:@selector(showDetailsView)
             forControlEvents:UIControlEventTouchUpInside];
      
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    
     else if([[annotation title] isEqualToString:@"School"])
    {
        
        annView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
        
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    
    else // if (![[annotation title] isEqualToString:@"Bus"])
    {
        annView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
        lbl.textColor = [UIColor blackColor];
        lbl.textAlignment= NSTextAlignmentCenter;
        lbl.alpha = 1;
        lbl.tag = 42;
        lbl.text = annotation.title;
        lbl.font = [UIFont fontWithName:@"Roboto-Medium" size:13];
        [annView addSubview:lbl];
        
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        //[infoButton addTarget:self action:@selector(showDetailsView)
        //  forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        //[annView addSubview:label];
    }
    return annView;
}


//
-(void)plotvehickePositionBus1:(NSString*)busposition
{
    
    for (id annotation in mkMapview.annotations)
    {
        if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions1"])
            [mkMapview removeAnnotation:annotation];
    }
    
    CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
    CGSize size = CGSizeMake(28, 36);
    
    NSArray *latlonArry = [busposition componentsSeparatedByString:@","];
    
    
    float lat = [[latlonArry objectAtIndex:0] floatValue];
    float longi = [[latlonArry objectAtIndex:1] floatValue];
    
    center.latitude = lat;//28.721145//-81.305078
    center.longitude=longi;
    
    for (id<MKAnnotation> annotation in mkMapview.annotations){
        MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
        
        if (![annotation.title isEqualToString:@"Bus"] || ![annotation.title isEqualToString:@"BusPostions1"] || ![annotation.title isEqualToString:@"BusPostions2"])
        {
            
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
            lbl.textColor = [UIColor blackColor];
            lbl.textAlignment= NSTextAlignmentCenter;
            lbl.alpha = 1;
            lbl.tag = 42;
            NSLog(@"%@ POsiton",annotation.title);
            NSString *Bustitme =[ NSString stringWithFormat:@"%@",annotation.title];
            
            if ([Bustitme isEqualToString:@"BusPostions2"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions1"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions3"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions4"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"Bus"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            
            else if (![Bustitme isEqualToString:@"BusPostions1"] && ![Bustitme isEqualToString:@"BusPostions2"] && ![Bustitme isEqualToString:@"Bus"] && ![Bustitme isEqualToString:@"BusPostions3"] && ![annotation.title isEqualToString:@"BusPostions4"]){
                lbl.text = annotation.title;
                // [anView addSubview:lbl];
                anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];
            }
            if([Bustitme isEqualToString:@"School"])
            {
                 anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            }
            //BusPostions2
            
        }
        else if([[annotation title] isEqualToString:@"School"])
        {
            
            anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            
            UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            
            anView.rightCalloutAccessoryView = infoButton;
            anView.canShowCallout = YES;
            
        }
        
        
        else
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            [infoButton addTarget:self action:@selector(showDetailsView)
                 forControlEvents:UIControlEventTouchUpInside];
            anView.rightCalloutAccessoryView = infoButton;
            anView.canShowCallout = YES;
        }
    }
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
    
   // MKCoordinateSpan span = MKCoordinateSpanMake(0.05, 0.05);
    //MKCoordinateRegion region = {coord, span};
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:coord];
    annotation.title=@"BusPostions1";
    
   // [mkMapview setRegion:region];
    [mkMapview addAnnotation:annotation];
    
}


-(void)plotvehickePositionBus2:(NSString*)busposition
{
    
    for (id annotation in mkMapview.annotations)
    {
        if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions2"])
            [mkMapview removeAnnotation:annotation];
    }
    
    CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
    CGSize size = CGSizeMake(28, 36);
    
    NSArray *latlonArry = [busposition componentsSeparatedByString:@","];
    
    
    float lat = [[latlonArry objectAtIndex:0] floatValue];
    float longi = [[latlonArry objectAtIndex:1] floatValue];
    
    center.latitude = lat;//28.721145//-81.305078
    center.longitude=longi;
    
    for (id<MKAnnotation> annotation in mkMapview.annotations){
        MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
        
        if (![annotation.title isEqualToString:@"Bus"] || ![annotation.title isEqualToString:@"BusPostions1"] || ![annotation.title isEqualToString:@"BusPostions2"])
        {
            
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
            lbl.textColor = [UIColor blackColor];
            lbl.textAlignment= NSTextAlignmentCenter;
            lbl.alpha = 1;
            lbl.tag = 42;
            NSLog(@"%@ POsiton",annotation.title);
            NSString *Bustitme =[ NSString stringWithFormat:@"%@",annotation.title];
            
            if ([Bustitme isEqualToString:@"BusPostions2"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions1"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions3"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions4"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"Bus"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            
            else if (![Bustitme isEqualToString:@"BusPostions1"] && ![Bustitme isEqualToString:@"BusPostions2"] && ![Bustitme isEqualToString:@"Bus"] && ![Bustitme isEqualToString:@"BusPostions3"] && ![annotation.title isEqualToString:@"BusPostions4"]){
                lbl.text = annotation.title;
                // [anView addSubview:lbl];
                anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];
            }
            
            
            if([Bustitme isEqualToString:@"School"])
            {
                anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            }
            
            //BusPostions2
            
        }
       else if([[annotation title] isEqualToString:@"School"])
       {
           
           anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
           
           UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
           
           anView.rightCalloutAccessoryView = infoButton;
           anView.canShowCallout = YES;
           
       }
       
       
       
       else
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        }
    }
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
    
   // MKCoordinateSpan span = MKCoordinateSpanMake(0.05, 0.05);
   // MKCoordinateRegion region = {coord, span};
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:coord];
    annotation.title=@"BusPostions2";
    
    
   // [mkMapview setRegion:region];
    [mkMapview addAnnotation:annotation];
}

//
-(void)plotvehickePositionBus3:(NSString*)busposition
{
    
    for (id annotation in mkMapview.annotations)
    {
        if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions3"] )
            [mkMapview removeAnnotation:annotation];
    }
    
    CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
    CGSize size = CGSizeMake(28, 36);
    
    NSArray *latlonArry = [busposition componentsSeparatedByString:@","];
    
    
    float lat = [[latlonArry objectAtIndex:0] floatValue];
    float longi = [[latlonArry objectAtIndex:1] floatValue];
    
    center.latitude = lat;//28.721145//-81.305078
    center.longitude=longi;
    
    for (id<MKAnnotation> annotation in mkMapview.annotations){
        MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
        
        if (![annotation.title isEqualToString:@"Bus"] || ![annotation.title isEqualToString:@"BusPostions1"] || ![annotation.title isEqualToString:@"BusPostions2"] || ![annotation.title isEqualToString:@"BusPostions3"])
        {
            
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
            lbl.textColor = [UIColor blackColor];
            lbl.textAlignment= NSTextAlignmentCenter;
            lbl.alpha = 1;
            lbl.tag = 42;
            NSLog(@"%@ POsiton",annotation.title);
            NSString *Bustitme =[ NSString stringWithFormat:@"%@",annotation.title];
            
            if ([Bustitme isEqualToString:@"BusPostions2"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions1"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions3"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions4"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"Bus"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if (![Bustitme isEqualToString:@"BusPostions1"] && ![Bustitme isEqualToString:@"BusPostions2"] && ![Bustitme isEqualToString:@"Bus"] && ![Bustitme isEqualToString:@"BusPostions3"] && ![annotation.title isEqualToString:@"BusPostions4"]){
                lbl.text = annotation.title;
                // [anView addSubview:lbl];
                anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];
            }
            
            if([Bustitme isEqualToString:@"School"])
            {
                anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            }
            
            //BusPostions2
            
        }
        else if([[annotation title] isEqualToString:@"School"])
        {
            
            anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            
            UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            
            anView.rightCalloutAccessoryView = infoButton;
            anView.canShowCallout = YES;
            
        }
        
        
        else
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            [infoButton addTarget:self action:@selector(showDetailsView)
                 forControlEvents:UIControlEventTouchUpInside];
            anView.rightCalloutAccessoryView = infoButton;
            anView.canShowCallout = YES;
        }
    }
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
    
    // MKCoordinateSpan span = MKCoordinateSpanMake(0.05, 0.05);
    // MKCoordinateRegion region = {coord, span};
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:coord];
    annotation.title=@"BusPostions3";
    
    // [mkMapview setRegion:region];
    [mkMapview addAnnotation:annotation];
}


//
-(void)plotvehickePositionBus4:(NSString*)busposition
{
    
    for (id annotation in mkMapview.annotations)
    {
        if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions4"])
            [mkMapview removeAnnotation:annotation];
    }
    
    CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
    CGSize size = CGSizeMake(28, 36);
    
    NSArray *latlonArry = [busposition componentsSeparatedByString:@","];
    
    
    float lat = [[latlonArry objectAtIndex:0] floatValue];
    float longi = [[latlonArry objectAtIndex:1] floatValue];
    
    center.latitude = lat;//28.721145//-81.305078
    center.longitude=longi;
    
    for (id<MKAnnotation> annotation in mkMapview.annotations){
        MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
        
        if (![annotation.title isEqualToString:@"Bus"] || ![annotation.title isEqualToString:@"BusPostions1"] || ![annotation.title isEqualToString:@"BusPostions2"]|| ![annotation.title isEqualToString:@"BusPostions3"] || ![annotation.title isEqualToString:@"BusPostions4"])
        {
            
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
            lbl.textColor = [UIColor blackColor];
            lbl.textAlignment= NSTextAlignmentCenter;
            lbl.alpha = 1;
            lbl.tag = 42;
            NSLog(@"%@ POsiton",annotation.title);
            NSString *Bustitme =[ NSString stringWithFormat:@"%@",annotation.title];
            
            if ([Bustitme isEqualToString:@"BusPostions2"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions1"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions3"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"BusPostions4"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            else if ([Bustitme isEqualToString:@"Bus"]) {
                anView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
            }
            
            else if (![Bustitme isEqualToString:@"BusPostions1"] && ![Bustitme isEqualToString:@"BusPostions2"] && ![Bustitme isEqualToString:@"Bus"] && ![Bustitme isEqualToString:@"BusPostions3"] && ![annotation.title isEqualToString:@"BusPostions4"]){
                lbl.text = annotation.title;
               // [anView addSubview:lbl];
                anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];
            }
            
            
            if([Bustitme isEqualToString:@"School"])
            {
                anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            }
            
            //BusPostions2
            
        }
        else if([[annotation title] isEqualToString:@"School"])
        {
            
            anView.image  = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            
            UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            
            anView.rightCalloutAccessoryView = infoButton;
            anView.canShowCallout = YES;
            
        }
        
        
        else
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            [infoButton addTarget:self action:@selector(showDetailsView)
                 forControlEvents:UIControlEventTouchUpInside];
            anView.rightCalloutAccessoryView = infoButton;
            anView.canShowCallout = YES;
        }
    }
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
    
    // MKCoordinateSpan span = MKCoordinateSpanMake(0.05, 0.05);
    // MKCoordinateRegion region = {coord, span};
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:coord];
    annotation.title=@"BusPostions4";
    
    
    // [mkMapview setRegion:region];
    [mkMapview addAnnotation:annotation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)back:(id)sender

{
    Home *mHome = [[Home alloc]initWithNibName:@"Home" bundle:nil];
    [self presentViewController:mHome animated:YES completion:nil];
}

-(IBAction)FilterBusss:(id)sender
{
    
    self.BuspopUpViewController = [[BusFilter alloc] initWithNibName:@"BusFilter" bundle:nil];
    [self.BuspopUpViewController setTitle:@"This is a popup view"];
   
    [self.BuspopUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
    
    
    //FilterBus.hidden= NO;
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"newFriendCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    //tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    cell.textLabel.text =[NSString stringWithFormat:@"Bus No :%ld",(long)indexPath.row+1];
    cell.textLabel.font=[UIFont fontWithName:@"Roboto-Medium" size:15.0f];
    return cell;
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    tableView.hidden=YES;
    
    //int index = indexPath.row+1;
    
    switch (indexPath.row) {
        case 0:
        {
            Busnumber= 1;
            
            BusarrayPlaces = [NSMutableArray arrayWithObjects:
                              @"28.759710, -81.322058",nil];
            studentPointLocationArray =[NSMutableArray arrayWithObjects:
                                        @"28.759551, -81.322060",
                                        @"28.759343, -81.322063",
                                        @"28.759189, -81.322066",
                                        @"28.759056, -81.322070",
                                                    nil];
            
            [self PlaceBusPositions:BusarrayPlaces];
            [self PlaceStudentLocationPoint:studentPointLocationArray];
            
            
            Bus1 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus1:)
                                                           userInfo: nil repeats:YES];

            
            [Bus2 invalidate];
             [Bus3 invalidate];
             [Bus4 invalidate];
            
            
            
        }
            
            break;
        case 1:
        {
             Busnumber= 2;
            BusarrayPlaces = [NSMutableArray arrayWithObjects:
                              @"28.759710, -81.322058",
                              @"28.759024, -81.320534",nil];
            studentPointLocationArray =[NSMutableArray arrayWithObjects:
                                        @"28.759551, -81.322060",
                                        @"28.759343, -81.322063",
                                        @"28.759189, -81.322066",
                                        @"28.759056, -81.322070",
                                        @"28.759038, -81.321371",
                                        @"28.759029, -81.321683",
                                        @"28.759027, -81.321971",
                                        @"28.758116, -81.322618",
                                        nil];
            
            
           
            
            
            
            
            [self PlaceBusPositions:BusarrayPlaces];
            [self PlaceStudentLocationPoint:studentPointLocationArray];
            
            
            Bus1 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus1:)
                                                           userInfo: nil repeats:YES];
            
            
            Bus2 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus2:)
                                                           userInfo: nil repeats:YES];
            
             [Bus3 invalidate];
             [Bus4 invalidate];
            
            
        }
            
            break;
        case 2:
            
        {
            BusarrayPlaces = [NSMutableArray arrayWithObjects:
                              @"28.759710, -81.322058",
                              @"28.759024, -81.320534",
                              @"28.758093, -81.320518",nil];
            
            
            studentPointLocationArray =[NSMutableArray arrayWithObjects:
                                        @"28.759551, -81.322060",
                                        @"28.759343, -81.322063",
                                        @"28.759189, -81.322066",
                                        @"28.759056, -81.322070",
                                        @"28.759038, -81.321371",
                                        @"28.759029, -81.321683",
                                        @"28.759027, -81.321971",
                                        @"28.758116, -81.322618",
                                        @"28.758370, -81.322099",
                                        @"28.758642, -81.322296",
                                        @"28.758931, -81.322334",
                                        @"28.758102, -81.320762",
                                        nil];
            [self PlaceBusPositions:BusarrayPlaces];
            [self PlaceStudentLocationPoint:studentPointLocationArray];
            Bus1 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus1:)
                                                           userInfo: nil repeats:YES];
            
            
            Bus2 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus2:)
                                                           userInfo: nil repeats:YES];
            Bus3 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus3:)
                                                           userInfo: nil repeats:YES];
            
            
             [Bus4 invalidate];

            
        }
            
            
            break;
        case 3:
        {
            BusarrayPlaces = [NSMutableArray arrayWithObjects:
                              @"28.759710, -81.322058",
                              @"28.759024, -81.320534",
                              @"28.758093, -81.320518",
                              @"28.758107, -81.322757", nil];
            studentPointLocationArray =[NSMutableArray arrayWithObjects:
                                        @"28.759551, -81.322060",
                                        @"28.759343, -81.322063",
                                        @"28.759189, -81.322066",
                                        @"28.759056, -81.322070",
                                        @"28.759033, -81.320877",
                                        @"28.759038, -81.321371",
                                        @"28.759029, -81.321683",
                                        @"28.759027, -81.321971",
                                        @"28.758116, -81.322618",
                                        @"28.758116, -81.322618",
                                        @"28.758370, -81.322099",
                                        @"28.758642, -81.322296",
                                        @"28.758931, -81.322334",
                                        @"28.758102, -81.320762",
                                        @"28.758105, -81.321269",
                                        @"28.758112, -81.321739",
                                        @"28.758626, -81.322073",nil];
            
            
            [self PlaceBusPositions:BusarrayPlaces];
            [self PlaceStudentLocationPoint:studentPointLocationArray];
            
            Bus1 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus1:)
                                                           userInfo: nil repeats:YES];
            
            
            Bus2 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus2:)
                                                           userInfo: nil repeats:YES];
            Bus3 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus3:)
                                                           userInfo: nil repeats:YES];
            
            Bus4 = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                             target: self
                                                           selector:@selector(onTickForBus4:)
                                                           userInfo: nil repeats:YES];
            
            
        }
            
            break;
            
            
        default:
            break;
    }
        
    
    
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
