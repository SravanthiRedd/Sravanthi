//
//  Driver2.h
//  SDCP
//
//  Created by venkat dubasi on 27/12/16.
//  Copyright © 2016 DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "PopUpViewController.h"
#import "ParentPopupController.h"

@interface Driver2 : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    //CLLocationManager *locationManager;
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
}
@property (nonatomic, strong)  PopUpViewController *popUpViewController;
@property (nonatomic, strong)  ParentPopupController *ParentPopupController;
@property (nonatomic, strong) IBOutlet MKMapView *mapView;
@property(strong,nonatomic) NSString *restartAt;
@property(strong,nonatomic) NSString *Trip;
@property(strong,nonatomic) NSString *startTrip;
@property(strong,nonatomic) NSString *endtripString;
@property(strong,nonatomic) NSString *studenCovedCnt;;

@property (nonatomic, strong) IBOutlet UILabel *label1;
@property (nonatomic, strong) IBOutlet UILabel *label2;
@property (nonatomic, strong) IBOutlet UILabel *label3;
@property (nonatomic, strong) IBOutlet UILabel *label4;


@property (nonatomic, strong) IBOutlet UILabel *label11;
@property (nonatomic, strong) IBOutlet UILabel *label21;
@property (nonatomic, strong) IBOutlet UILabel *label31;
@property (nonatomic, strong) IBOutlet UILabel *label41;

@end
