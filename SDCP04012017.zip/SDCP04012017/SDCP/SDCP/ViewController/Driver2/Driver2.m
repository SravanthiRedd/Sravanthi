//
//  Driver2.m
//  SDCP
//
//  Created by venkat dubasi on 27/12/16.
//  Copyright © 2016 DEVPOINT. All rights reserved.
//

#import "Driver2.h"
#import "MapPoint.h"


@interface Driver2 ()<MKMapViewDelegate,CLLocationManagerDelegate>
{
     //CurrentLocation *clocation;
     UITableView *table;
     NSUserDefaults *mPref;
     NSMutableArray *locationObjest;
    NSArray *Busrayya;
    NSTimeInterval timeInterval;
    NSArray *StudentStopsArray;
    int studentstopCoverdCnt;
    
 }
@end

@implementation Driver2
NSString *const LATITUDE =@"Latitude";
NSString *const LONGITUDE =@"Longitude";
@synthesize mapView;
- (void)viewDidLoad {
    [super viewDidLoad];
    Busrayya = [[NSMutableArray alloc]init];
    locationObjest = [[NSMutableArray alloc]init];
    
    studentstopCoverdCnt = 0;
   
    
    
    if ([self.Trip isEqualToString:@"Pickup"]) {
        NSLog(@"PickUp");
        
        locationObjest = [NSMutableArray arrayWithObjects:@"28.758114, -81.322537",
                          @"28.758111, -81.322151",
                          @"28.758108, -81.321464",
                          @"28.759153, -81.322079", nil];
        
        
       
        [self plotPositions :locationObjest];
      
        [mapView setShowsUserLocation:YES];
        
        
        Busrayya = [self setBusTravvalues];
        
        
        //timeInterval=[Busrayya count];
          self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        
        self.label11.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        
        timeInterval=0;
        
        if(self.restartAt!=nil)
        {
            timeInterval = [self.restartAt intValue];
            studentstopCoverdCnt = [self.studenCovedCnt intValue];
        }
        else
        {
            [self showCurrentLocationAddressss:@"28.758127, -81.322913"];
        }
        
        
        NSTimer *t = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                      target: self
                                                    selector:@selector(onTick:)
                                                    userInfo: nil repeats:YES];

        NSLog(@"timer %@",t);
        
    }
    else if ([self.Trip isEqualToString:@"Drop Off"])
    {
        
        
        if(![self.endtripString isEqualToString:@"PopUpEnd"] && ![self.endtripString isEqualToString:@"endTrip"])
        {
        
            
            NSTimer *t = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                          target: self
                                                        selector:@selector(TrippopUp:)
                                                        userInfo: nil repeats:NO];
            NSLog(@"timer %@",t);

            
        
            
            
            
            
//        self.popUpViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
//       // [self.popUpViewController setTitle:@"This is a popup view"];
//        self.popUpViewController.popupTitle = @"End Trip";
//        self.popUpViewController.Page =@"Driver";
//        self.popUpViewController.trip= self.Trip;
//        self.popUpViewController.EndTripString= @"PopUpEnd";
//        [self.popUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
        
        }
        
        StudentStopsArray = [NSMutableArray arrayWithObjects:
                          @"28.759153, -81.322079",
                          @"28.758108, -81.321464",
                          @"28.758111, -81.322151",
                          @"28.758114, -81.322537",nil];
        
     
        
        Busrayya = [self setBusTravvalues];
        timeInterval=[Busrayya count];
        
      
    
        
        NSTimer *t = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                      target: self
                                                    selector:@selector(onEndTrip:)
                                                    userInfo: nil repeats:YES];
          NSLog(@"timer %@",t);
        
        [self PlaceEndTripStudentLocations:StudentStopsArray];
        
        if(self.restartAt!=nil)
        {
            timeInterval = [self.restartAt intValue];
             studentstopCoverdCnt = [self.studenCovedCnt intValue];
        }
        else
        {
            //    @"28.759012, -81.323709",
            
            [self placeBusposioton:@"28.759012, -81.323709"];
        }

    }
    
    
    mapView.delegate = self;
    
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        //locationManager.allowsBackgroundLocationUpdates = YES;
    }
    [locationManager startUpdatingLocation];
    
    
    NSString *schollHub= @"28.759013, -81.323789";
    [self PlaceschoolHub:schollHub];
    
    
    CLLocationCoordinate2D centre = [mapView centerCoordinate];
    
    float lat = [@"28.759013" floatValue];
    float longi = [@"-81.323789" floatValue];
    
    centre.latitude = lat;//28.721145//-81.305078
    centre.longitude=longi;
    MKCoordinateRegion region;
    region.span.latitudeDelta = 0.002;
    region.span.longitudeDelta = 0.002;
    if (firstLaunch) {
        region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1500,1500);
        firstLaunch=YES;
    }else {
        //Set the center point to the visible region of the map and change the radius to match the search radius passed to the Google query string.
        region.center.latitude = lat;//{desired lat};
        region.center.longitude =longi;// {desired lng};
        
    }
    region.span.latitudeDelta = 0.002;
    region.span.longitudeDelta = 0.002;
    region = [mapView regionThatFits:region];
    [mapView setRegion:region animated:TRUE];
    
    
    self.label1.layer.cornerRadius = self.label1.frame.size.width/2;
    self.label1.layer.borderColor=[UIColor blackColor].CGColor;
    self.label1.layer.borderWidth = 1.0;
    self.label1.layer.masksToBounds = YES;
    
    self.label2.layer.cornerRadius = self.label2.frame.size.width/2;
    self.label2.layer.borderColor=[UIColor blackColor].CGColor;
    self.label2.layer.borderWidth = 1.0;
    self.label2.layer.masksToBounds = YES;
    
    self.label3.layer.cornerRadius = self.label3.frame.size.width/2;
    self.label3.layer.borderColor=[UIColor blackColor].CGColor;
    self.label3.layer.borderWidth = 1.0;
    self.label3.layer.masksToBounds = YES;
    
    self.label4.layer.cornerRadius = self.label4.frame.size.width/2;
    self.label4.layer.borderColor=[UIColor blackColor].CGColor;
    self.label4.layer.borderWidth = 1.0;
    self.label4.layer.masksToBounds = YES;
    
    [self setlabelColor:studentstopCoverdCnt];

    
    
    
}

-(void)TrippopUp:(NSTimer*)timer
{
    self.popUpViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
    [self.popUpViewController setTitle:@"This is a popup view"];
    self.popUpViewController.startAt =[NSString stringWithFormat:@"%f",timeInterval];
    self.popUpViewController.Page =@"Driver";
    self.popUpViewController.popupTitle= @"End Trip";
    self.popUpViewController.trip= self.Trip;
    self.popUpViewController.EndTripString= @"PopUpEnd";
    self.popUpViewController.studentCovereCnt =[NSString stringWithFormat:@"%d",studentstopCoverdCnt];
    [self.popUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
}

-(void)setlabelColor:(int)cnt

{
    if(studentstopCoverdCnt ==1)
    {
        self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label11.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
    }
    else if (studentstopCoverdCnt ==2)
    {
        self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label11.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
    }
    
    else if (studentstopCoverdCnt ==3)
    {
        self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label11.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label3.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label31.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        
    }

    
    else if (studentstopCoverdCnt ==4)
    {
        self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label11.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label3.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label31.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        
        self.label4.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        self.label41.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        
    }

}



-(void)PlaceschoolHub:(NSString*)place
{
    if (place!=nil) {
        
        CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
        CGSize size = CGSizeMake(28, 28);
        
        NSArray *latlong = [place componentsSeparatedByString:@","];
        
        
        float lat = [[latlong objectAtIndex:0] floatValue];
        float longi = [[latlong objectAtIndex:1] floatValue];
        
        center.latitude = lat;//28.721145//-81.305078mapViewmapViewmapView
        center.longitude=longi;
        
        for (id<MKAnnotation> annotation in mapView.annotations){
            
      MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
            if (![[annotation title] isEqualToString:@"Bus"] && ![[annotation title] isEqualToString:@"BusPostions"] && ![[annotation title] isEqualToString:@"School"])
            {
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                
                
                anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage imageNamed:@"points.png" ];
                // UILabel *label = [UILabel new];
                // label.text = @"1";
                
                UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
                // lbl.backgroundColor = [UIColor blackColor];
                lbl.textColor = [UIColor blackColor];
                lbl.textAlignment= NSTextAlignmentCenter;
                lbl.alpha = 1;
                lbl.tag = 42;
                lbl.text = annotation.title;
                [anView addSubview:lbl];
                
                
                //}// [mkMapview removeAnnotation:annotation];
                
            }
            else if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions"])
            {
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            }
            else if ([[annotation title] isEqualToString:@"School"])
            {
                anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
                
            }

            
        }
        
        
        
        
        
        
        
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
        
        MKCoordinateSpan span = MKCoordinateSpanMake(0.5, 0.5);
        MKCoordinateRegion region = {coord, span};
        
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        [annotation setCoordinate:coord];
        annotation.title=@"School";
        
        [mapView setRegion:region];
        [mapView addAnnotation:annotation];
        
    }
    
    
    
}


-(void)onEndTrip:(NSTimer*)Timer
{
    //NSArray *endTripArra = [self EndTripArray];
    
    if (timeInterval < 0) {
        [Timer invalidate];
        
    }
    else
    {
         timeInterval = timeInterval-1;
        
        NSString *busPosition= [Busrayya objectAtIndex:timeInterval];
        
        [self showDropTrip:busPosition];
       
        
        for (int i=0; i<[StudentStopsArray count]; i++) {
            
            //NSArray *latlong = [[StudentStopsArray objectAtIndex:i] componentsSeparatedByString:@","];
            
            NSString *LatLong1 = [StudentStopsArray objectAtIndex:i];
            
            NSString *LatLong2 = busPosition;
            
            BOOL Statu =  [self distance:LatLong1 Location2:LatLong2];
            
            if (Statu) {
                [Timer invalidate];
            }
            
            if ([LatLong2  isEqual:@"28.758108, -81.321464"]) {
                self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
            }
            else if ([LatLong2  isEqual:@"28.758111, -81.322151"]) {
                self.label3.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                self.label31.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
            }
            else if ([LatLong2  isEqual:@"28.758114, -81.322537"]) {
                self.label4.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                
                self.label41.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                
            }
            else if ([LatLong2  isEqual:@"28.759153, -81.322079"]) {
                self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                self.label11.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
            }
            
            
        }
    }

}


-(void)showDropTrip:(NSString*)dropTriplatlong
{
    for (id annotation in mapView.annotations)
    {
        if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions"])
            [mapView removeAnnotation:annotation];
    }
    
    CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
    CGSize size = CGSizeMake(28, 28);
    
    NSArray *latlong=  [dropTriplatlong componentsSeparatedByString:@","];
    
    float lat = [[latlong objectAtIndex:0] floatValue];
    float longi = [[latlong objectAtIndex:1] floatValue];
    
    center.latitude = lat;//28.721145//-81.305078
    center.longitude=longi;
    
    for (id<MKAnnotation> annotation in mapView.annotations){
        MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
        
        
        if (![[annotation title] isEqualToString:@"Bus"] && ![[annotation title] isEqualToString:@"BusPostions"] && ![[annotation title] isEqualToString:@"School"])
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            
            
            anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage imageNamed:@"points.png" ];
            // UILabel *label = [UILabel new];
            // label.text = @"1";
            
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
            // lbl.backgroundColor = [UIColor blackColor];
            lbl.textColor = [UIColor blackColor];
            lbl.textAlignment= NSTextAlignmentCenter;
            lbl.alpha = 1;
            lbl.tag = 42;
            lbl.text = annotation.title;
            [anView addSubview:lbl];
            
            
            //}// [mkMapview removeAnnotation:annotation];
            
        }
        else if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions"])
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        }
        else if ([[annotation title] isEqualToString:@"School"])
        {
            anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            
        }

    
    
    
    
    
    
    
    }
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
    
    MKCoordinateSpan span = MKCoordinateSpanMake(0.003, 0.003);
    MKCoordinateRegion region = {coord, span};
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:coord];
    annotation.title=@"BusPostions";
    
    [mapView setRegion:region];
    [mapView addAnnotation:annotation];
}


-(void)PlaceEndTripStudentLocations:(NSArray*)Places
{
    @try {
        
        //Remove any existing custom annotations but not the user location blue dot.
        for (id<MKAnnotation> annotation in mapView.annotations)
        {
            if ([annotation isKindOfClass:[MapPoint class]])
            {
                [mapView removeAnnotation:annotation];
            }
        }
        
        //Loop through the array of places returned from the Google API.
        for (int i=0; i<[Places count]; i++)
        {
            
            //Retrieve the NSDictionary object in each index of the array.
            NSArray* place = [[Places objectAtIndex:i] componentsSeparatedByString:@","];
            
            //Get our name and address info for adding to a pin.
            int numr = i+1;
            NSString *name=[NSString stringWithFormat:@"%d",numr];
            NSString *vicinity= @"";
            CLLocationCoordinate2D coordinate;
            
            //Set the lat and long.
            coordinate.latitude=[[place objectAtIndex:0] doubleValue];
            coordinate.longitude=[[place objectAtIndex:1] doubleValue];
            
            MapPoint *placeObject = [[MapPoint alloc] initWithName:name address:vicinity coordinate:coordinate];
            [mapView addAnnotation:placeObject];
            
        }
        
    }
    @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }

}

-(NSArray*)StartTrip
{
    return nil;
}



-(NSArray *)EndTripArray
{
    
    
    
    NSArray *endTripArray= [NSArray arrayWithObjects:
                            @"28.759937, -81.323261",
                            @"28.759936, -81.323127",
                            @"28.759936, -81.323004",
                            @"28.759929, -81.322844",
                            @"28.759941, -81.322755",
                            @"28.759940, -81.322675",
                            @"28.759942, -81.322576",
                            @"28.759947, -81.322496",
                            @"28.759929, -81.322672",
                            @"28.759934, -81.322653",
                            @"28.759940, -81.322617",
                            @"28.759939, -81.322575",
                            @"28.759940, -81.322533",
                            @"28.759937, -81.322467",
                            @"28.759937, -81.322404",
                            @"28.759941, -81.322297",
                            @"28.759947, -81.322229",
                            @"28.759936, -81.322070",
                            @"28.759937, -81.322033",
                            @"28.759948, -81.321965",
                            @"28.759941, -81.321845",
                            @"28.759943, -81.321708",
                            @"28.759942, -81.321595",
                            @"28.759944, -81.321502",
                            @"28.759945, -81.321359",
                            @"28.759944, -81.321502",
                            @"28.759942, -81.321595",
                            @"28.759943, -81.321708",
                            @"28.759941, -81.321845",
                            @"28.759948, -81.321965",
                            @"28.759941, -81.322070",
                            @"28.759941, -81.322070",
                            @"28.759831, -81.322070",
                            @"28.759792, -81.322074",
                            @"28.759410, -81.322075",
                            @"28.759329, -81.322073",
                            @"28.759137, -81.322073",
                            @"28.759072, -81.322077",
                            @"28.759016, -81.322074",
                            @"28.759019, -81.322106",
                            @"28.759022, -81.322160",
                            @"28.759019, -81.322224",
                            @"28.759023, -81.322298",
                            @"28.759024, -81.322377",
                            @"28.759024, -81.322425", nil];
    
    return endTripArray;
}


-(NSArray *)setBusTravvalues
{
   
    NSArray *stratTriparray =[NSArray arrayWithObjects:@"28.758127, -81.322913",
    @"28.758125, -81.322825",
    @"28.758124, -81.322759",
    @"28.758122, -81.322698",
    @"28.758117, -81.322604",
    @"28.758114, -81.322537",
    @"28.758111, -81.322467",
    @"28.758111, -81.322402",
    @"28.758111, -81.322344",
    @"28.758115, -81.322290",
    @"28.758113, -81.322206",
    @"28.758111, -81.322151",
    @"28.758104, -81.322082",
    
    @"28.758104, -81.322018",
    @"28.758112, -81.321937",
    @"28.758107, -81.321872",
    @"28.758108, -81.321801",
    @"28.758106, -81.321715",
    @"28.758106, -81.321652",
    @"28.758103, -81.321597",
    @"28.758104, -81.321530",
    @"28.758108, -81.321464",
    @"28.758104, -81.321530",
    @"28.758103, -81.321597",
    @"28.758106, -81.321652",
    @"28.758106, -81.321715",
    @"28.758108, -81.321801",
    @"28.758107, -81.321872",
    @"28.758112, -81.321937",
    @"28.758104, -81.322018",
    
    @"28.758183, -81.322076",
    @"28.758257, -81.322075",
    @"28.758370, -81.322080",
    @"28.758506, -81.322076",
    @"28.758616, -81.322068",
    @"28.758744, -81.322074",
    @"28.758817, -81.322079",
    @"28.758885, -81.322075",
    @"28.758951, -81.322076",
    @"28.759017, -81.322084",
    @"28.759098, -81.322084",
    @"28.759153, -81.322079",
    @"28.759098, -81.322084",
    @"28.759017, -81.322084",
    @"28.759017, -81.322144",
    @"28.759017, -81.322235",
    @"28.759015, -81.322334",
    @"28.759018, -81.322502",
    @"28.759020, -81.322603",
    @"28.759022, -81.322680",
    @"28.759027, -81.322749",
    @"28.759018, -81.322830",
    @"28.759017, -81.322880",
    @"28.759022, -81.322952",
    @"28.759022, -81.323031",
    @"28.759022, -81.323125",
    @"28.759020, -81.323184",
    @"28.759020, -81.323273",
    @"28.759013, -81.323370",
    @"28.759021, -81.323604",
    @"28.759012, -81.323709",

    nil];
    
    
    return stratTriparray;
  
//@"28.759020, -81.322603"
}


-(void)onTick:(NSTimer*)time
{
    
    //NSArray *endTrip = [self EndTripArray];
    
    if (timeInterval == [Busrayya count] ) {
        [time invalidate];
    }
    else
    {
      
        
        NSString *busPosition= [Busrayya objectAtIndex:timeInterval];
        
        [self plotvehickePosition:busPosition];
          timeInterval = timeInterval+1;
        
        for (int i=0; i<[locationObjest count]; i++) {
            NSString *LatLong1 = [locationObjest objectAtIndex:i];
            
            NSString *LatLong2 =busPosition;
            
            BOOL Statu =  [self distance:LatLong1 Location2:LatLong2];
            
            if (Statu) {
                [time invalidate];
            }
            
            if ([LatLong2  isEqual:@"28.758104, -81.322018"]) {
                self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                
                self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                
            }
            else if ([LatLong2  isEqual:@"28.758112, -81.321937"]) {
                self.label3.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                self.label31.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
            }
            else if ([LatLong2  isEqual:@"28.759098, -81.322084"]) {
                self.label4.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
                self.label41.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
            }
            
            
        }
    }
    
    
    
}


-(BOOL)distance:(NSString*)Location1 Location2:(NSString*)Location2
{
    NSArray  *location1Arra = [Location1 componentsSeparatedByString:@","];
    NSArray  *location2Arra = [Location2 componentsSeparatedByString:@","];
    
    float lat1 = [[location1Arra objectAtIndex:0] floatValue];
    float long1 = [[location1Arra objectAtIndex:1] floatValue];
    float lat2 = [[location2Arra objectAtIndex:0] floatValue];
    float long2 = [[location2Arra objectAtIndex:1] floatValue];
    
    CLLocation *locA = [[CLLocation alloc] initWithLatitude:lat1 longitude:long1];
    
    CLLocation *locB = [[CLLocation alloc] initWithLatitude:lat2 longitude:long2];
    
    CLLocationDistance distance = [locA distanceFromLocation:locB];
    
    int Number = [[NSString stringWithFormat:@"%g",distance] intValue];
    
    NSLog(@"%d",Number);
    
    //if(Number  <=5  && Number>=0)
    //{
        
        if ([Location1 isEqualToString:Location2]) {
            studentstopCoverdCnt= studentstopCoverdCnt+1;
            self.popUpViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
            [self.popUpViewController setTitle:@"This is a popup view"];
            self.popUpViewController.startAt =[NSString stringWithFormat:@"%f",timeInterval];
            self.popUpViewController.Page =@"Driver";
            self.popUpViewController.popupTitle= @"Student List";
            self.popUpViewController.trip= self.Trip;
            self.popUpViewController.EndTripString= @"endTrip";
            self.popUpViewController.studentCovereCnt =[NSString stringWithFormat:@"%d",studentstopCoverdCnt];
            [self.popUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
            return YES;

     //   }
            
            
            
            
        
        
        
    }
    return  NO;
    
}



-(void)placeBusposioton:(NSString*)locatioString
{
    @try {
        
        if (locatioString!=nil) {
            
            
            CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
            
            NSArray *latlong = [locatioString componentsSeparatedByString:@","];
            
            CGSize size = CGSizeMake(28, 28);
            float lat = [[latlong objectAtIndex:0] floatValue];
            float longi = [[latlong objectAtIndex:1] floatValue];
            
            center.latitude = lat;//28.721145//-81.305078
            center.longitude=longi;
            
            for (id<MKAnnotation> annotation in mapView.annotations){
                MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                
                //if (anView){
                //  [mapView removeAnnotation:annotation];
                //}
            }
            
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
            
            MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
            MKCoordinateRegion region = {coord, span};
            
            MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
            [annotation setCoordinate:coord];
            annotation.title=@"Bus";
            
            [mapView setRegion:region];
            [mapView addAnnotation:annotation];
            
        }
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}


-(void)plotvehickePosition:(NSString*)busposition
{
    
    
    for (id annotation in mapView.annotations)
    {
        if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions"])
            [mapView removeAnnotation:annotation];
    }
    
    
    
    CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
    CGSize size = CGSizeMake(28, 28);
    NSArray *latlong = [busposition componentsSeparatedByString:@","];
    
    //CGSize size = CGSizeMake(28, 28);
    float lat = [[latlong objectAtIndex:0] floatValue];
    float longi = [[latlong objectAtIndex:1] floatValue];

    
    center.latitude = lat;//28.721145//-81.305078
    center.longitude=longi;
    
    for (id<MKAnnotation> annotation in mapView.annotations){
        MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
        
        
        
        if (![[annotation title] isEqualToString:@"Bus"] && ![[annotation title] isEqualToString:@"BusPostions"] && ![[annotation title] isEqualToString:@"School"])
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            
            
            anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage imageNamed:@"points.png" ];
            // UILabel *label = [UILabel new];
            // label.text = @"1";
            
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
            // lbl.backgroundColor = [UIColor blackColor];
            lbl.textColor = [UIColor blackColor];
            lbl.textAlignment= NSTextAlignmentCenter;
            lbl.alpha = 1;
            lbl.tag = 42;
            lbl.text = annotation.title;
            [anView addSubview:lbl];
            
            
            //}// [mkMapview removeAnnotation:annotation];
            
        }
        else if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions"])
        {
            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        }
        else if ([[annotation title] isEqualToString:@"School"])
        {
            anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            
        }
        
        if ([busposition isEqualToString:@"28.758104, -81.322082"]) {
             anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
        }
        
        
//        if (![[annotation title] isEqualToString:@"Bus"] || ![[annotation title] isEqualToString:@"BusPostions"])
//        {
//            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
//            
//            
//            anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage imageNamed:@"points.png" ];
//            // UILabel *label = [UILabel new];
//            // label.text = @"1";
//            
//            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
//            // lbl.backgroundColor = [UIColor blackColor];
//            lbl.textColor = [UIColor blackColor];
//            lbl.textAlignment= NSTextAlignmentCenter;
//            lbl.alpha = 1;
//            lbl.tag = 42;
//            lbl.text = annotation.title;
//            [anView addSubview:lbl];
//            
//            
//            
//            //}// [mkMapview removeAnnotation:annotation];
//            
//        }else
//        {
//            anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
//        }
    }
    
    CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
    
    MKCoordinateSpan span = MKCoordinateSpanMake(0.002, 0.002);
    MKCoordinateRegion region = {coord, span};
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:coord];
    annotation.title=@"BusPostions";
    
    [mapView setRegion:region];
    [mapView addAnnotation:annotation];
    
    
}


- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
    
    if ([[annotation title] isEqualToString:@"Current Location"]) {
        return nil;
    }
    
    CGSize size = CGSizeMake(28, 28);
    
    MKAnnotationView *annView = [[MKAnnotationView alloc ] initWithAnnotation:annotation reuseIdentifier:@"currentloc"];
    if ([[annotation title] isEqualToString:@"Bus"])
    {
        annView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
//        [infoButton addTarget:self action:@selector(DriverPopUp)
//             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    else if ([[annotation title] isEqualToString:@"BusPostions"])
    {
        annView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
//        [infoButton addTarget:self action:@selector(DriverPopUp)
//             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    
    
    else // if (![[annotation title] isEqualToString:@"Bus"])
    {
        annView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage imageNamed:@"points.png" ];
        // UILabel *label = [UILabel new];
        // label.text = @"1";
        
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
        // lbl.backgroundColor = [UIColor blackColor];
        lbl.textColor = [UIColor blackColor];
        lbl.textAlignment= NSTextAlignmentCenter;
        lbl.alpha = 1;
        lbl.tag = 42;
        lbl.text = annotation.title;
        [annView addSubview:lbl];
        
        
        
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [infoButton addTarget:self action:@selector(showDetailsView)
          forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        //[annView addSubview:label];
    }
    return annView;
}




-(void)showDetailsView
{
    self.popUpViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
    [self.popUpViewController setTitle:@"This is a popup view"];
    self.popUpViewController.popupTitle= @"Student List";
    
    [self.popUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
    
}


- (UIImage *)image:(UIImage*)originlimage scaledToSize:(CGSize)size {
    //avoid redundant drawing
    if (CGSizeEqualToSize(originlimage.size, size))
    {
        return originlimage;
    }
    
    //create drawing context
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    
    //draw
    [originlimage drawInRect:CGRectMake(0.0f, 0.0f, size.width, size.height)];
    
    //capture resultant image
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    //return image
    return image;
}

-(void)showCurrentLocationAddress:(NSDictionary*)locatioString
{
    @try {        
        
        if (locatioString!=nil) {
             NSLog(@"TEst");
            
            CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
            
            float lat = [[locatioString valueForKey:@"Latitiude"] floatValue];
            float longi = [[locatioString valueForKey:@"Longitude"] floatValue];
            
            center.latitude = lat;//28.721145//-81.305078
            center.longitude=longi;
            
            for (id<MKAnnotation> annotation in mapView.annotations){
                MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
                anView.image=[UIImage imageNamed:@"bus.png"];
                
                //if (anView){
                  //  [mapView removeAnnotation:annotation];
                //}
            }
            
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
            
            MKCoordinateSpan span = MKCoordinateSpanMake(0.002, 0.002);
            MKCoordinateRegion region = {coord, span};
            
            MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
            [annotation setCoordinate:coord];
            annotation.title=@"Bus";
            
            [self.mapView setRegion:region];
            [self.mapView addAnnotation:annotation];
            
        }
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
    self.popUpViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
    [self.popUpViewController setTitle:@"This is a popup view"];
    self.popUpViewController.popupTitle= @"Student List";
    
    [self.popUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
    
    
 
}


- (void)plotPositions:(NSMutableArray *)studentLocations
{
    @try {
        
        //Remove any existing custom annotations but not the user location blue dot.
        for (id<MKAnnotation> annotation in mapView.annotations)
        {
            if ([annotation isKindOfClass:[MapPoint class]])
            {
                [mapView removeAnnotation:annotation];
            }
        }
        
        //Loop through the array of places returned from the Google API.
        for (int i=0; i<[studentLocations count]; i++)
        {
            
            //Retrieve the NSDictionary object in each index of the array.
            NSString* place = [locationObjest objectAtIndex:i];
            NSArray *loccationArray = [place componentsSeparatedByString:@","];
            
            //Get our name and address info for adding to a pin.
            int numr = i+1;
            NSString *name=[NSString stringWithFormat:@"%d",numr];
            NSString *vicinity= @"";
            CLLocationCoordinate2D coordinate;
            
            //Set the lat and long.
            coordinate.latitude=[[loccationArray objectAtIndex:0] doubleValue];
            coordinate.longitude=[[loccationArray objectAtIndex:1] doubleValue];
          
            MapPoint *placeObject = [[MapPoint alloc] initWithName:name address:vicinity coordinate:coordinate];
            [mapView addAnnotation:placeObject];            
            
        }
        
    }
    @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}


//------------ Current Location Address-----

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    currentLocation = [locations objectAtIndex:0];
    [locationManager stopUpdatingLocation];
    CLGeocoder *geocoder = [[CLGeocoder alloc] init] ;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showCurrentLocationAddressss:(NSString*)locatioString
{
    @try {
        
        if (locatioString!=nil) {
            
            
            CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
            CGSize size = CGSizeMake(28, 28);
            
            NSArray *latlong = [locatioString componentsSeparatedByString:@","];
            
            float lat = [[latlong objectAtIndex:0] floatValue];
            float longi = [[latlong objectAtIndex:1] floatValue];
            
            center.latitude = lat;//28.721145//-81.305078
            center.longitude=longi;
            
            for (id<MKAnnotation> annotation in mapView.annotations){
                MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                
                //if (anView){
                //  [mapView removeAnnotation:annotation];
                //}
            }
            
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
            
            MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
            MKCoordinateRegion region = {coord, span};
            
            MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
            [annotation setCoordinate:coord];
            annotation.title=@"Bus";
            
            [mapView setRegion:region];
            [mapView addAnnotation:annotation];
            
        }
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}




-(IBAction)back:(id)sender
{
    Home *mhome = [[Home alloc]initWithNibName:@"Home" bundle:nil];
    [self presentViewController:mhome animated:YES completion:nil];

    
    
  //  [self dismissViewControllerAnimated:YES
     //                        completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
