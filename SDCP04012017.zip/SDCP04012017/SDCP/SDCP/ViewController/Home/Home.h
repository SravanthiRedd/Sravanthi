//
//  Home.h
//  SDCP
//
//  Created by sravanthi Gumma on 06/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Home : UIViewController
@property(strong,nonatomic) IBOutlet UIButton *TripDropDownBtn;
@property (strong ,nonatomic)  UITableView *table;
@property(weak,nonatomic) IBOutlet UIView *DropdownSection;
@property(weak,nonatomic) IBOutlet UIView *dropView;


@end
