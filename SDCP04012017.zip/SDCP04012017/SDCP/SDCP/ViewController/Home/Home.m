//
//  Home.m
//  SDCP
//
//  Created by sravanthi Gumma on 06/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import "Home.h"
#import "Driver2.h"
#import "SideMenu.h"

@interface Home ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
{
    NSArray *Trips;
    NSString *selctedTrip;
    NSString *SlideMenuTag;
    NSString *Trip;
}



//bus_45.png
//bus_90.png
//bus_135.png
//bus_180.png
//bus_215.png
//bus_245.png
//bus_290.png
//bus_360.png




@end

@implementation Home

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    Trips=@[@"Pickup",@"Drop Off"];
    SlideMenuTag = @"Show";
    Trip= @"Pickup";
    
    
    self.dropView.layer.borderWidth=0.5;
     self.dropView.layer.borderColor = [UIColor colorWithRed:232.0/256.0 green:232.0/256.0 blue:232.0/256.0 alpha:1].CGColor;
    
    
   // [[self.dropView layer] setBorderWidth:(0.5f)];
    //
    self.table = [[UITableView alloc]initWithFrame:CGRectMake(self.dropView.frame.origin.x, self.dropView.frame.origin.y+30,self.dropView.frame.size.width , 100) style:UITableViewStylePlain];
    self.table.delegate = self;
    self.table.dataSource= self;
    self.table.hidden= YES;
    [self.view addSubview:self.table];
    
   //  [self LocalNotification];
    
    
//    NSTimer *t = [NSTimer scheduledTimerWithTimeInterval: 3.0
//                                                  target: self
//                                                selector:@selector(localNotification:)
//                                                userInfo: nil repeats:YES];
    
}

-(void)localNotification:(NSTimer*)timer
{
   //
}








- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)TripDropDownBtn:(id)sender
{
    self.table.hidden = NO;
    [self.table reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [Trips count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        static NSString *CellIdentifier = @"newFriendCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        //tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        cell.textLabel.text = [Trips objectAtIndex:indexPath.row];
        cell.textLabel.font=[UIFont fontWithName:@"Roboto-Medium" size:15.0f];
    CGSize size = CGSizeMake(24, 24);
    cell.imageView.frame = CGRectMake(0, 5, 24, 24);
        cell.imageView.image =  [self image:[UIImage imageNamed:@"pickup.png"] scaledToSize:size];//[UIImage imageNamed:@"pickup.png"];
        return cell;
    
 }

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   [self.TripDropDownBtn setTitle:[Trips objectAtIndex:indexPath.row] forState:UIControlStateNormal];
    self.table.hidden = YES;
    Trip =[Trips objectAtIndex:indexPath.row];
 }
- (UIImage *)image:(UIImage*)originlimage scaledToSize:(CGSize)size {
    //avoid redundant drawing
    if (CGSizeEqualToSize(originlimage.size, size))
    {
        return originlimage;
    }
    
    //create drawing context
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    
    //draw
    [originlimage drawInRect:CGRectMake(0.0f, 0.0f, size.width, size.height)];
    
    //capture resultant image
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    //return image
    return image;
}


-(void) viewDidLayoutSubviews {
    
    @try {
        
        [super viewDidLayoutSubviews];
        //[self.scrollview layoutIfNeeded];
       // self.scrollview.contentSize=self.contentView.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"pagebg.jpg"];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"pagebg.jpg"]];
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)next:(id)sender
{
    Driver2 *mDriver2 = [[Driver2 alloc]initWithNibName:@"Driver2" bundle:nil];
    mDriver2.Trip= Trip;
    [self presentViewController:mDriver2 animated:YES completion:nil];
}


-(IBAction)MenuBtn:(id)sender
{
    [self slideShowHideMenu];
}


- (void)slideShowHideMenu {
    
    @try {
        
        
        //
        SideMenu *tlc = [[SideMenu alloc]initWithNibName:@"SideMenu" bundle:nil];
        [tlc.view setFrame:CGRectMake(0, 65, 250, self.view.frame.size.height)];
        
        if ([SlideMenuTag isEqualToString:@"Show"])
        {
            
            tlc.view.layer.shadowColor = [UIColor grayColor].CGColor;
            tlc.view.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
            tlc.view.layer.borderWidth=0.5f;
            tlc.view.layer.shadowOffset = CGSizeMake(3.0, 5.0);
            
            
            [self addChildViewController:tlc];
            [self.view addSubview:tlc.view];
            [tlc didMoveToParentViewController:self];
            
            SlideMenuTag = @"Hide";
        }
        else
            if ([SlideMenuTag isEqualToString:@"Hide"])
            {
                SlideMenuTag = @"Show";
                
                [UIView animateWithDuration:0.1 animations:^{
                    [tlc.view setFrame:CGRectMake(0, 65, 0, 0)];
                    SideMenu *tlc = [self.childViewControllers lastObject];
                    [tlc didMoveToParentViewController:nil];
                    [tlc.view removeFromSuperview];
                    [tlc removeFromParentViewController];
                  
                }];
            }
        
    } @catch (NSException *exception) {
      //  [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}



@end
