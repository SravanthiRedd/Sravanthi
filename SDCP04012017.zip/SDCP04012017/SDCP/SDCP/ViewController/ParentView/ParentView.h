//
//  ParentView.h
//  SDCP
//
//  Created by sravanthi Gumma on 09/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>


@interface ParentView : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    //CLLocationManager *locationManager;
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
}
@property(strong,nonatomic) NSString *restartAt;



@property (nonatomic, strong) IBOutlet UILabel *label1;
@property (nonatomic, strong) IBOutlet UILabel *label2;
@property (nonatomic, strong) IBOutlet UILabel *label3;
@property (nonatomic, strong) IBOutlet UILabel *label4;


@property (nonatomic, strong) IBOutlet UILabel *label11;
@property (nonatomic, strong) IBOutlet UILabel *label21;
@property (nonatomic, strong) IBOutlet UILabel *label31;
@property (nonatomic, strong) IBOutlet UILabel *label41;


@end
