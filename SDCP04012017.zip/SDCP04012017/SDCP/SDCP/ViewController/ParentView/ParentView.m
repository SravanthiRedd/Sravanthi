//
//  ParentView.m
//  SDCP
//
//  Created by sravanthi Gumma on 09/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import "ParentView.h"
#import "ParentPopupController.h"
#import "MapPoint.h"
#import "PopUpViewController.h"
#import "Home.h"

@interface ParentView ()
{
 
    UITableView *table;
    NSUserDefaults *mPref;
    NSMutableArray *locationObjest;
    NSString *LATITUDE;// =@"Latitude";
    NSString *LONGITUDE;// =@"Longitude";
    NSMutableArray *Busrayya;
    NSTimeInterval timeInterval;
    
}
@property (nonatomic, strong)  ParentPopupController *ParentPopupController;
@property (nonatomic, strong)  PopUpViewController *popUpViewController;
@property (nonatomic, strong) IBOutlet MKMapView *mkMapview;

@end


@implementation ParentView


@synthesize mkMapview;
- (void)viewDidLoad {
    [super viewDidLoad];
     LATITUDE =@"Latitude";
    LONGITUDE =@"Longitude";
    Busrayya = [[NSMutableArray alloc]init];
    locationObjest = [[NSMutableArray alloc]init];
   //  [self LocalNotification];

    
    
    NSDictionary *obj10=@{@"Latitiude":@"28.759239",
                          @"Longitude":@"-81.322069"
                          };
    NSDictionary *obj20=@{@"Latitiude":@"28.759732",
                          @"Longitude":@"-81.322057"
                          };
    NSDictionary *obj30=@{@"Latitiude":@"28.759939",
                          @"Longitude":@"-81.321572"
                          };
    NSDictionary *obj40=@{@"Latitiude":@"28.759943",
                          @"Longitude":@"-81.322456"
                          };
    
    
    
    NSDictionary *vehicleObj=@{@"Latitiude":@"28.759014",
                               @"Longitude":@"-81.322697"
                               };
    
    //28.759939, -81.323641
    NSString *schollHub= @"28.759939, -81.323641";
    [self PlaceschoolHub:schollHub];
    
    //28.745410, -81.314342
    [locationObjest addObject:obj10];
    [locationObjest addObject:obj20];
    [locationObjest addObject:obj30];
    [locationObjest addObject:obj40];
    [self plotPositionsss :locationObjest];
    Busrayya = [self setBusTravvalues];
    
     self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
     self.label11.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
    
    timeInterval=0;
    
    if(self.restartAt!=nil)
    {
        timeInterval = [self.restartAt intValue];
    }
    else
    {
        [self showCurrentLocationAddressss:vehicleObj];
    }
    
   
    
    // Do any additional setup after loading the view from its nib.
    self.mkMapview.delegate = self;
    
    self.mkMapview.delegate = self;
    
    // Ensure that we can view our own location in the map view.
  //
    
    //Instantiate a location object.
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        //locationManager.allowsBackgroundLocationUpdates = YES;
    }
    [locationManager startUpdatingLocation];
    
    CLLocation *location = [locationManager location];
    // coordinate = [location coordinate];
    CLLocationCoordinate2D centre = [self.mkMapview centerCoordinate];
    
    
    float lat = [@"28.759027" floatValue];
    float longi = [@"-81.322502" floatValue];
    
    centre.latitude = lat;//28.721145//-81.305078
    centre.longitude=longi;
    MKCoordinateRegion region;
    if (firstLaunch) {
        region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1500,1500);
        firstLaunch=YES;
    }else {
        
        
      //  MKCoordinateRegion region;
        region.center.latitude = lat;//{desired lat};
        region.center.longitude =longi;// {desired lng};
        region.span.latitudeDelta = 0.002;
        region.span.longitudeDelta = 0.002;
        region = [mkMapview regionThatFits:region];
        [mkMapview setRegion:region animated:TRUE];
        
       
        
    }
    
    //  NSString *locationstring = [mPref valueForKey:@"StoredAddress"];
    
    //Set the visible region of the map.
      [self.mkMapview setShowsUserLocation:YES];
   // [mkMapview setRegion:region animated:YES];
   // mkMapview.centerCoordinate = location.coordinate;
    
    self.label1.layer.cornerRadius = self.label1.frame.size.width/2;
    self.label1.layer.borderColor=[UIColor blackColor].CGColor;
    self.label1.layer.borderWidth = 1.0;
    self.label1.layer.masksToBounds = YES;
    
    self.label2.layer.cornerRadius = self.label2.frame.size.width/2;
    self.label2.layer.borderColor=[UIColor blackColor].CGColor;
    self.label2.layer.borderWidth = 1.0;
    self.label2.layer.masksToBounds = YES;
    
    self.label3.layer.cornerRadius = self.label3.frame.size.width/2;
    self.label3.layer.borderColor=[UIColor blackColor].CGColor;
    self.label3.layer.borderWidth = 1.0;
    self.label3.layer.masksToBounds = YES;
    
    self.label4.layer.cornerRadius = self.label4.frame.size.width/2;
    self.label4.layer.borderColor=[UIColor blackColor].CGColor;
    self.label4.layer.borderWidth = 1.0;
    self.label4.layer.masksToBounds = YES;

    
    
    NSTimer *t = [NSTimer scheduledTimerWithTimeInterval: 3.0
                                                  target: self
                                                selector:@selector(onTick:)
                                                userInfo: nil repeats:YES];
    
}

-(void)plotvehickePosition:(NSDictionary*)busposition
{
    
    
    for (id annotation in mkMapview.annotations)
    {
        if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions"])
            [mkMapview removeAnnotation:annotation];
    }
    
    
    
        CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
        CGSize size = CGSizeMake(28, 28);
    
   // NSArray *latlong =[ busposition componentsSeparatedByString:@","];
    
        float lat = [[busposition valueForKey:@"Latitiude"] floatValue];
        float longi =[[busposition valueForKey:@"Longitude"] floatValue];
        
        center.latitude = lat;//28.721145//-81.305078
        center.longitude=longi;
        
        for (id<MKAnnotation> annotation in mkMapview.annotations){
            MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
           
            
            if (![[annotation title] isEqualToString:@"Bus"] || ![[annotation title] isEqualToString:@"BusPostions"])
            {
                //anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                
                
                anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage imageNamed:@"points.png" ];
                // UILabel *label = [UILabel new];
                // label.text = @"1";
                
                UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
                // lbl.backgroundColor = [UIColor blackColor];
                lbl.textColor = [UIColor blackColor];
                lbl.textAlignment= NSTextAlignmentCenter;
                lbl.alpha = 1;
                lbl.tag = 42;
               //lbl.text = annotation.title;
                //[anView addSubview:lbl];

                
                NSString *bustitle =[NSString stringWithFormat:@"%@",[annotation title]];
                
                 if ([bustitle isEqualToString:@"School"])
                {
                    
                    anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
                    
                }
                
                
                
            //}// [mkMapview removeAnnotation:annotation];
            
            }
            
            else if ([[annotation title] isEqualToString:@"School"])
            {
                         
                anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
            
            }
            
            
            else
            {
                
                
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            }
        }
        
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
        
        MKCoordinateSpan span = MKCoordinateSpanMake(0.002, 0.002);
        MKCoordinateRegion region = {coord, span};
        
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        [annotation setCoordinate:coord];
        annotation.title=@"BusPostions";
        
        [mkMapview setRegion:region];
        [mkMapview addAnnotation:annotation];
    
    
}


-(BOOL)distance:(NSString*)Location1 Location2:(NSString*)Location2
{
    NSArray  *location1Arra = [Location1 componentsSeparatedByString:@","];
      NSArray  *location2Arra = [Location2 componentsSeparatedByString:@","];
    
    float lat1 = [[location1Arra objectAtIndex:0] floatValue];
    float long1 = [[location1Arra objectAtIndex:1] floatValue];
    float lat2 = [[location2Arra objectAtIndex:0] floatValue];
    float long2 = [[location2Arra objectAtIndex:1] floatValue];
    
    CLLocation *locA = [[CLLocation alloc] initWithLatitude:lat1 longitude:long1];
    
    CLLocation *locB = [[CLLocation alloc] initWithLatitude:lat2 longitude:long2];
    
    CLLocationDistance distance = [locA distanceFromLocation:locB];
    
    int Number = [[NSString stringWithFormat:@"%g",distance] intValue];
    
    
    if(Number<8 && Number>0)
    {
        

        
        
        
        
        
//            self.popUpViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
//            [self.popUpViewController setTitle:@"This is a popup view"];
//        self.popUpViewController.startAt =[NSString stringWithFormat:@"%f",timeInterval];
//        self.popUpViewController.Page =@"Parent";
//            [self.popUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
        return YES;
        
    }
    return  NO;
    
}

-(void)onTick:(NSTimer*)time
{
    
    if (timeInterval ==[Busrayya count] ) {
        [time invalidate];
    }
    else
    {
    
    NSDictionary *busPosition= [Busrayya objectAtIndex:timeInterval];
    
     [self plotvehickePosition:busPosition];
    timeInterval = timeInterval+1;
    
    for (int i=0; i<[locationObjest count]; i++) {
        NSString *LatLong1 =[NSString stringWithFormat:@"%@,%@",[[locationObjest objectAtIndex:i] valueForKey:@"Latitiude"],[[locationObjest objectAtIndex:i]   valueForKey:@"Longitude"]];
        
          NSString *LatLong2 = [NSString stringWithFormat:@"%@,%@",[busPosition valueForKey:@"Latitiude"],[busPosition  valueForKey:@"Longitude"]];
        
    BOOL Statu =  [self distance:LatLong1 Location2:LatLong2];
        
        
//        NSDictionary *obj20=@{@"Latitiude":@"28.759732",
//                              @"Longitude":@"-81.322057"
//                              };
//        NSDictionary *obj30=@{@"Latitiude":@"28.759939",
//                              @"Longitude":@"-81.321572"
//                              };
//        NSDictionary *obj40=@{@"Latitiude":@"28.759943",
//                              @"Longitude":@"-81.322456"
//                              };
//
//        
//        NSDictionary *obj1=@{@"Latitiude":@"28.759025",
//                             @"Longitude":@"-81.322243"
//                             };
//        
//        NSDictionary *obj2=@{@"Latitiude":@"28.759738",
//                             @"Longitude":@"-81.322066"
//                             };
//        
//        NSDictionary *obj3=@{@"Latitiude":@"28.759930",
//                             @"Longitude":@"-81.321852"
//                             };
//        
//        
//        NSDictionary *obj4=@{@"Latitiude":@"28.759946",
//                             @"Longitude":@"-81.321867"
//                             };
//        
//
        
        
        
        if ([LatLong2  isEqual:@"28.759666,-81.322059"]) {
            self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
              self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        }
        else if ([LatLong2  isEqual:@"28.759953,-81.321754"]) {
            self.label3.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
             self.label31.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        }
        else if ([LatLong2  isEqual:@"28.759958,-81.322377"]) {
            self.label4.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
            self.label41.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
        }
        
        
        
        
        
        
//        
//        if ([LatLong2  isEqual:@"28.758108, -81.321464"]) {
//            self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//             self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//        }
//        else if ([LatLong2  isEqual:@"28.758111, -81.322151"]) {
//            self.label3.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//             self.label31.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//        }
//        else if ([LatLong2  isEqual:@"28.758114, -81.322537"]) {
//            self.label4.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//             self.label41.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//        }
//        else if ([LatLong2  isEqual:@"28.759153, -81.322079"]) {
//            self.label1.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//             self.label1.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//        }
//        
//        
        
//        
//        if ([LatLong2  isEqual:@"28.759738, -81.322066"]) {
//            self.label2.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//            
//            self.label21.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//            
//        }
//        else if ([LatLong2  isEqual:@"28.759930, -81.321852"]) {
//            self.label3.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//            self.label31.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//        }
//        else if ([LatLong2  isEqual:@"28.759946, -81.321867"]) {
//            self.label4.backgroundColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//            self.label41.textColor=[UIColor colorWithRed:243.0/256.0 green:179.0/256.0 blue:0.0/256.0 alpha:1];
//        }
//
        
        
        
        //if (Statu) {
       // [time invalidate];
        //}
  
    }
    }
    
    
  
}



//8
//



-(NSMutableArray *)setBusTravvalues
{
    
//    NSDictionary *obj10=@{@"Latitiude":@"28.759239",
//                          @"Longitude":@"-81.322069"
//                          };
//    NSDictionary *obj20=@{@"Latitiude":@"28.759732",
//                          @"Longitude":@"-81.322057"
//                          };
//    NSDictionary *obj30=@{@"Latitiude":@"28.759939",
//                          @"Longitude":@"-81.321572"
//                          };
//    NSDictionary *obj40=@{@"Latitiude":@"28.759943",
//                          @"Longitude":@"-81.322456"
//                          };


    
    
    NSDictionary *bus1=@{@"Latitiude":@"28.759014",
                          @"Longitude":@"-81.322697"
                          };
    NSDictionary *bus2=@{@"Latitiude":@"28.759022",
                          @"Longitude":@"-81.322571"
                          };
    NSDictionary *bus3=@{@"Latitiude":@"28.759027",
                          @"Longitude":@"-81.322502"
                          };
    NSDictionary *bus4=@{@"Latitiude":@"28.759028",
                          @"Longitude":@"-81.322407"
                          };
    
    NSDictionary *bus5=@{@"Latitiude":@"28.759025",
                         @"Longitude":@"-81.322243"
                         };
    NSDictionary *bus6=@{@"Latitiude":@"28.759023",
                         @"Longitude":@"-81.322079"
                         };
    NSDictionary *bus7=@{@"Latitiude":@"28.759153",
                         @"Longitude":@"-81.322077"
                         };
    
    
    NSDictionary *bus8=@{@"Latitiude":@"28.759086",
                         @"Longitude":@"-81.322066"
                         };
    
    
    NSDictionary *bus9=@{@"Latitiude":@"28.759371",
                         @"Longitude":@"-81.322082"
                         };
    
    
    NSDictionary *bus10=@{@"Latitiude":@"28.759365",
                         @"Longitude":@"-81.322072"
                         };
    
    
 

    
    
    NSDictionary *bus11=@{@"Latitiude":@"28.759738",
                         @"Longitude":@"-81.322066"
                         };
    
    NSDictionary *bus12=@{@"Latitiude":@"28.759540",
                         @"Longitude":@"-81.322085"
                         };

    
    
    NSDictionary *bus13=@{@"Latitiude":@"28.759666",
                         @"Longitude":@"-81.322059"
                         };
    NSDictionary *bus14=@{@"Latitiude":@"28.759859",
                         @"Longitude":@"-81.322064"
                         };
    NSDictionary *bus15=@{@"Latitiude":@"28.759930",
                         @"Longitude":@"-81.321852"
                         };
    NSDictionary *bus16=@{@"Latitiude":@"28.759951",
                         @"Longitude":@"-81.321694"
                         };
    NSDictionary *bus17=@{@"Latitiude":@"28.759937",
                          @"Longitude":@"-81.321549"
                          };
    
    
    
    
    
    
    NSDictionary *bus18=@{@"Latitiude":@"28.759953",
                          @"Longitude":@"-81.321754"
                          };

    
    NSDictionary *bus19=@{@"Latitiude":@"28.759946",
                          @"Longitude":@"-81.321867"
                          };

    
    
    NSDictionary *bus20=@{@"Latitiude":@"28.759948",
                          @"Longitude":@"-81.321885"
                          };

    
    
    NSDictionary *bus21=@{@"Latitiude":@"28.759941",
                          @"Longitude":@"-81.322071"
                          };

    
    
    NSDictionary *bus22=@{@"Latitiude":@"28.759946",
                          @"Longitude":@"-81.322208"
                          };

    
    NSDictionary *bus23=@{@"Latitiude":@"28.759962",
                          @"Longitude":@"-81.322259"
                          };

    NSDictionary *bus24=@{@"Latitiude":@"28.759958",
                          @"Longitude":@"-81.322377"
                          };

    NSDictionary *bus25=@{@"Latitiude":@"28.759935",
                          @"Longitude":@"-81.322642"
                          };

    NSDictionary *bus26=@{@"Latitiude":@"28.759937",
                          @"Longitude":@"-81.322698"
                          };
    NSDictionary *bus27=@{@"Latitiude":@"28.759937",
                          @"Longitude":@"-81.322799"
                          };
  

    
    NSDictionary *bus28=@{@"Latitiude":@"28.759940",
                          @"Longitude":@"-81.322903"
                          };
    
    NSDictionary *bus29=@{@"Latitiude":@"28.759933",
                          @"Longitude":@"-81.323026"
                          };
    NSDictionary *bus30=@{@"Latitiude":@"28.759942",
                          @"Longitude":@"-81.323109"
                          };
    NSDictionary *bus31=@{@"Latitiude":@"28.759940",
                          @"Longitude":@"-81.323378"
                          };
    
    NSDictionary *bus32=@{@"Latitiude":@"28.759939",
                          @"Longitude":@"-81.323641"
                          };




    
    
    
    
    
    [Busrayya addObject:bus1];
     [Busrayya addObject:bus2];
     [Busrayya addObject:bus3];
     [Busrayya addObject:bus4];
     [Busrayya addObject:bus5];
     [Busrayya addObject:bus6];

     [Busrayya addObject:bus11];
     [Busrayya addObject:bus12];
     [Busrayya addObject:bus13];
    [Busrayya addObject:bus14];
     [Busrayya addObject:bus15];
     [Busrayya addObject:bus16];
     [Busrayya addObject:bus17];
     [Busrayya addObject:bus18];
     [Busrayya addObject:bus19];
     [Busrayya addObject:bus20];
     [Busrayya addObject:bus21];
     [Busrayya addObject:bus22];
     [Busrayya addObject:bus23];
     [Busrayya addObject:bus24];
     [Busrayya addObject:bus25];
     [Busrayya addObject:bus26];
      [Busrayya addObject:bus27];
      [Busrayya addObject:bus28];
      [Busrayya addObject:bus29];
      [Busrayya addObject:bus30];
      [Busrayya addObject:bus31];
      [Busrayya addObject:bus32];
    
    
    return Busrayya;
}









- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
    
    if ([[annotation title] isEqualToString:@"Current Location"]) {
        return nil;
    }
    
    CGSize size = CGSizeMake(28, 28);
    
    MKAnnotationView *annView = [[MKAnnotationView alloc ] initWithAnnotation:annotation reuseIdentifier:@"currentloc"];
    if ([[annotation title] isEqualToString:@"Bus"])
    {
        annView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [infoButton addTarget:self action:@selector(DriverPopUp)
             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    else if ([[annotation title] isEqualToString:@"BusPostions"])
    {
        
       annView.image = [self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [infoButton addTarget:self action:@selector(DriverPopUp)
             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        
    }
    else if ([[annotation title] isEqualToString:@"School"])
    {
        annView.image = [self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
//        [infoButton addTarget:self action:@selector(DriverPopUp)
//             forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;

    }
    

   
    
    else // if (![[annotation title] isEqualToString:@"Bus"])
    {
        annView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
        // lbl.backgroundColor = [UIColor blackColor];
        lbl.textColor = [UIColor blackColor];
        lbl.textAlignment= NSTextAlignmentCenter;
        lbl.alpha = 1;
        lbl.tag = 42;
        lbl.text = annotation.title;
        [annView addSubview:lbl];
        
        
        
        UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        //[infoButton addTarget:self action:@selector(showDetailsView)
           //  forControlEvents:UIControlEventTouchUpInside];
        annView.rightCalloutAccessoryView = infoButton;
        annView.canShowCallout = YES;
        //[annView addSubview:label];
    }
    return annView;
}




-(void)DriverPopUp
{
    
        self.ParentPopupController = [[ParentPopupController alloc] initWithNibName:@"ParentPopupController" bundle:nil];
        [self.ParentPopupController setTitle:@"This is a popup view"];
    
        [self.ParentPopupController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
}


- (UIImage *)image:(UIImage*)originlimage scaledToSize:(CGSize)size {
    //avoid redundant drawing
    if (CGSizeEqualToSize(originlimage.size, size))
    {
        return originlimage;
    }
    
    //create drawing context
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    
    //draw
    [originlimage drawInRect:CGRectMake(0.0f, 0.0f, size.width, size.height)];
    
    //capture resultant image
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    //return image
    return image;
}

-(void)showCurrentLocationAddressss:(NSDictionary*)locatioString
{
    @try {
        
        if (locatioString!=nil) {
            
            
            CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
            CGSize size = CGSizeMake(28, 28);
            float lat = [[locatioString valueForKey:@"Latitiude"] floatValue];
            float longi = [[locatioString valueForKey:@"Longitude"] floatValue];
            
            center.latitude = lat;//28.721145//-81.305078
            center.longitude=longi;
            
            for (id<MKAnnotation> annotation in mkMapview.annotations){
                MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                
                
                UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
                [infoButton addTarget:self action:@selector(showDetailsView)
                     forControlEvents:UIControlEventTouchUpInside];
                anView.rightCalloutAccessoryView = infoButton;
                anView.canShowCallout = YES;
                
                
                
                //if (anView){
                //  [mapView removeAnnotation:annotation];
                //}
            }
            
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
            
            MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
            MKCoordinateRegion region = {coord, span};
            
            MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
            [annotation setCoordinate:coord];
            annotation.title=@"Bus";
            
            [mkMapview setRegion:region];
            [mkMapview addAnnotation:annotation];
            
        }
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}
-(void)showDetailsView
{
    self.ParentPopupController = [[ParentPopupController alloc] initWithNibName:@"ParentPopupController" bundle:nil];
        [self.ParentPopupController setTitle:@"This is a popup view"];
    
        [self.ParentPopupController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
}


- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
//    self.popUpViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
//    [self.popUpViewController setTitle:@"This is a popup view"];
//    
//    [self.popUpViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
    
    
    //  [mapView deselectAnnotation:view.annotation animated:YES];
    
    //    DetailsViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailsPopover"];
    //    controller.annotation = view.annotation;
    //    self.popover = [[UIPopoverController alloc] initWithContentViewController:controller];
    //    self.popover.delegate = self;
    //    [self.popover presentPopoverFromRect:view.frame
    //                                  inView:view.superview
    //                permittedArrowDirections:UIPopoverArrowDirectionAny
    //                                animated:YES];
}


- (void)plotPositionsss:(NSMutableArray *)locationObjest
{
    @try {
        
        //Remove any existing custom annotations but not the user location blue dot.
        for (id<MKAnnotation> annotation in mkMapview.annotations)
        {
            if ([annotation isKindOfClass:[MapPoint class]])
            {
                [mkMapview removeAnnotation:annotation];
            }
        }
        
        //Loop through the array of places returned from the Google API.
        for (int i=0; i<[locationObjest count]; i++)
        {
            
            //Retrieve the NSDictionary object in each index of the array.
            NSDictionary* place = [locationObjest objectAtIndex:i];
            
            //Get our name and address info for adding to a pin.
            int numr = i+1;
            NSString *name=[NSString stringWithFormat:@"%d",numr];
            NSString *vicinity= @"";
            CLLocationCoordinate2D coordinate;
            
            //Set the lat and long.
            coordinate.latitude=[[place objectForKey:@"Latitiude"] doubleValue];
            coordinate.longitude=[[place objectForKey:@"Longitude"] doubleValue];
            
            MapPoint *placeObject = [[MapPoint alloc] initWithName:name address:vicinity coordinate:coordinate];
            [mkMapview addAnnotation:placeObject];
            
        }
        
    }
    @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}


//------------ Current Location Address-----

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    currentLocation = [locations objectAtIndex:0];
    [locationManager stopUpdatingLocation];
    CLGeocoder *geocoder = [[CLGeocoder alloc] init] ;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction)back:(id)sender
{
    
    Home *mhome = [[Home alloc]initWithNibName:@"Home" bundle:nil];
    [self presentViewController:mhome animated:YES completion:nil];
    
   // [self dismissViewControllerAnimated:YES
                          //   completion:nil];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

-(void)PlaceschoolHub:(NSString*)place
{
    if (place!=nil) {
        
        CLLocationCoordinate2D center;//   =  [clocation getLocationFromAddressString:locatioString];
        CGSize size = CGSizeMake(28, 28);
        
        NSArray *latlong = [place componentsSeparatedByString:@","];
        
        
        float lat = [[latlong objectAtIndex:0] floatValue];
        float longi = [[latlong objectAtIndex:1] floatValue];
        
        center.latitude = lat;//28.721145//-81.305078mapViewmapViewmapView
        center.longitude=longi;
        
        for (id<MKAnnotation> annotation in mkMapview.annotations){
            
            MKAnnotationView* anView = [mkMapview viewForAnnotation: annotation];
            if (![[annotation title] isEqualToString:@"Bus"] && ![[annotation title] isEqualToString:@"BusPostions"] && ![[annotation title] isEqualToString:@"School"])
            {
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
                
                
                anView.image = [self image:[UIImage imageNamed:@"points.png"] scaledToSize:size];// [ UIImage imageNamed:@"points.png" ];
                // UILabel *label = [UILabel new];
                // label.text = @"1";
                
                UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(5, 2, 15, 15)];
                // lbl.backgroundColor = [UIColor blackColor];
                lbl.textColor = [UIColor blackColor];
                lbl.textAlignment= NSTextAlignmentCenter;
                lbl.alpha = 1;
                lbl.tag = 42;
                lbl.text = annotation.title;
                [anView addSubview:lbl];
                
                
                //}// [mkMapview removeAnnotation:annotation];
                
            }
            else if ([[annotation title] isEqualToString:@"Bus"] || [[annotation title] isEqualToString:@"BusPostions"])
            {
                anView.image=[self image:[UIImage imageNamed:@"bus.png"] scaledToSize:size];
            }
            else if ([[annotation title] isEqualToString:@"School"])
            {
                anView.image=[self image:[UIImage imageNamed:@"Marker Filled.png"] scaledToSize:size];
                
            }
            
            
        }
        
        
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
        
        MKCoordinateSpan span = MKCoordinateSpanMake(0.5, 0.5);
        MKCoordinateRegion region = {coord, span};
        
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        [annotation setCoordinate:coord];
        annotation.title=@"School";
        
        [mkMapview setRegion:region];
        [mkMapview addAnnotation:annotation];
        
    }
    
    
    
}


@end
