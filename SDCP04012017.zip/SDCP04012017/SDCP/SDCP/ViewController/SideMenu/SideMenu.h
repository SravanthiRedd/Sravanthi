//
//  SideMenu.h
//  SDCP
//
//  Created by sravanthi Gumma on 09/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SideMenu : UIViewController
@property (nonatomic, strong) IBOutlet UIImageView *imageview;
@property (nonatomic,weak) IBOutlet UIView *userTypeView;
@property (nonatomic,weak) IBOutlet UILabel *loginType;
@property (nonatomic, strong) IBOutlet UITableView *myTableView;
@end
