//
//  SideMenu.m
//  SDCP
//
//  Created by sravanthi Gumma on 09/10/1938 Saka.
//  Copyright © 1938 Saka DEVPOINT. All rights reserved.
//

#import "SideMenu.h"
#import "Driver2.h"
#import "Home.h"
#import "ParentView.h"
#import "AdminView.h"
#ifdef __IPHONE_6_0
# define LINE_BREAK_WORD_WRAP NSLineBreakByWordWrapping
#else
# define LINE_BREAK_WORD_WRAP UILineBreakModeWordWrap
#endif


#import "MainCellLeft.h"


@interface SideMenu ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *typearry;
}
@end

@implementation SideMenu

- (void)viewDidLoad {
    [super viewDidLoad];
    typearry = [NSArray arrayWithObjects:@"Admin View",@"Parent View",@"Driver View",nil];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewDidUnload {
    [super viewDidUnload];
}

#pragma mark -
#pragma mark View Will/Did Appear

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma mark -
#pragma mark View Will/Did Disappear

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try {
     
         return typearry.count;
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MainCellLeft *cell = (MainCellLeft *)[tableView dequeueReusableCellWithIdentifier:@"MainCellLeft"];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MainCellLeft" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    // tableView.backgroundColor = [UIColor blackColor];
    cell.title.text = typearry[indexPath.row];
    
    if([typearry[indexPath.row] isEqualToString:@"Driver View"])
    {
         cell.Image.image = [UIImage imageNamed:@"navbus.png"];
    }
    else  if([typearry[indexPath.row] isEqualToString:@"Parent View"])
    {
         cell.Image.image = [UIImage imageNamed:@"student_dummyicon.png"];
        
    }
    else  if([typearry[indexPath.row] isEqualToString:@"Admin View"])
    {
         cell.Image.image = [UIImage imageNamed:@"professional.png"];
    }
 
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
            
        case 0:
        {
            
            AdminView *mParentView = [[AdminView alloc]initWithNibName:@"AdminView" bundle:nil];
            [self presentViewController:mParentView animated:YES completion:nil];
        }
            break;
            
            
        case 1:
        {
           
            ParentView *mParentView = [[ParentView alloc]initWithNibName:@"ParentView" bundle:nil];
            [self presentViewController:mParentView animated:YES completion:nil];
        }
            break;
            
        case 2:
        {
            Home *mHome = [[Home alloc]initWithNibName:@"Home" bundle:nil];
            [self presentViewController:mHome animated:YES completion:nil];
        }
            break;
    }
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
